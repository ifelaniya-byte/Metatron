//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BLZ8J4bb.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/api/$",
			"/v1/$"
		],
		preloads: ["/assets/index-BVK-Grcw.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BVK-Grcw.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-ahHqlIM9.js"]
	}
} });
//#endregion
export { tsrStartManifest };
