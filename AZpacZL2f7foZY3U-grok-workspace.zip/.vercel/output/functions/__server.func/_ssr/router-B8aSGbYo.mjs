import { i as __toESM } from "../_runtime.mjs";
import { a as listLibrary, f as getScale, i as getEngine, l as sleep, m as __exportAll, n as createFromModelfile, o as listLoaded, r as deleteModel, s as pullModel, t as copyModel, u as trainMore } from "./runtime-DqGp884e.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as useRouter, f as createRouter, g as createRootRoute, h as createFileRoute, l as Scripts, m as lazyRouteComponent, p as Outlet, u as HeadContent, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-B8aSGbYo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: error.message || "An unexpected error occurred. Try reloading the page."
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	if (typeof window === "undefined") return () => {};
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	const parentOrigin = resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		if (envelope.data.type === "hello") {
			if (!HelloSchema.safeParse(event.data).success) return;
			announce();
			return;
		}
		if (envelope.data.type === "navigate") {
			const parsed = NavigateSchema.safeParse(event.data);
			if (!parsed.success) return;
			navigate(parsed.data.path);
			queueMicrotask(reportLocation);
			return;
		}
		if (envelope.data.type === "history") {
			const parsed = HistorySchema.safeParse(event.data);
			if (!parsed.success) return;
			if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
			window.history.go(parsed.data.delta);
		}
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-DZEAb0Qq.css";
var APP_NAME = "Metatron";
var Route$3 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#09090b"
			},
			{
				name: "description",
				content: "Flower-of-Life geometric language model, loaded as an Ollama runtime."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "bg-bg font-sans text-fg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	})
});
var $$splitComponentImporter = () => import("./routes-C3z5BJTb.mjs");
var Route$2 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
function nowIso() {
	return (/* @__PURE__ */ new Date()).toISOString();
}
function modelCard(scale, engine, name) {
	const tag = name ?? engine?.alias ?? scale.tag;
	return {
		name: tag,
		model: tag,
		modified_at: nowIso(),
		size: scale.params * 4,
		digest: `sha256:${scale.digest}${"0".repeat(48)}`.slice(0, 71),
		details: {
			parent_model: "",
			format: "gguf",
			family: "metatron",
			families: ["metatron", "flower-of-life"],
			parameter_size: scale.sizeLabel,
			quantization_level: "F32"
		}
	};
}
function tagsPayload() {
	const extras = /* @__PURE__ */ new Set();
	const models = listLibrary().map((e) => {
		extras.add(e.scale.tag);
		return modelCard(e.scale, e, e.alias ?? e.scale.tag);
	});
	if (!extras.has("metatron:latest")) {
		const ultra = getEngine("ultra");
		models.push(modelCard(ultra.scale, ultra, "metatron:latest"));
	}
	return { models };
}
function showPayload(name) {
	const scale = getScale(name);
	return {
		...modelCard(scale, getEngine(name), name.replace(/^ollama\//, "")),
		modelfile: modelfileFor(scale),
		parameters: `temperature 0.3\nnum_ctx ${scale.ctx}\ntop_k 40\nrepeat_penalty 1.1`,
		template: "{{ .System }}\n\nUser: {{ .Prompt }}\nMetatron: ",
		system: "You are Metatron, a Flower-of-Life geometric language model.",
		license: "Metatron geometric runtime. Not a GGUF transformer."
	};
}
function modelfileFor(scale) {
	return `FROM metatron:${scale.id}
PARAMETER temperature 0.3
PARAMETER num_ctx ${scale.ctx}
PARAMETER top_k 40
PARAMETER stop "User:"
PARAMETER stop "<|im_end|>"
SYSTEM """
You are Metatron, a Flower-of-Life geometric modular language model.
Organs: brain, memory, ears, mouth, hands, heart, legs.
Keep replies concise. Do not pretend to be a frontier transformer.
"""
`;
}
function openclawSnippet(scale, origin) {
	return `{
  "agents": {
    "defaults": {
      "model": { "primary": "ollama/${scale.tag}" },
      "models": {
        "ollama/${scale.tag}": {}
      }
    }
  },
  "plugins": {
    "entries": {
      "ollama": { "enabled": true }
    }
  },
  "models": {
    "providers": {
      "ollama": {
        "baseUrl": "${origin}",
        "api": "ollama",
        "apiKey": "ollama-local",
        "models": [
          {
            "id": "${scale.tag}",
            "name": "${scale.tag}",
            "reasoning": false,
            "input": ["text"],
            "contextWindow": ${Math.max(8192, scale.ctx)},
            "maxTokens": 1024,
            "compat": {
              "supportsTools": false,
              "supportsUsageInStreaming": true
            }
          }
        ]
      }
    }
  }
}`;
}
function psPayload() {
	return { models: listLoaded().map((e) => ({
		...modelCard(e.scale, e, e.alias ?? e.scale.tag),
		expires_at: new Date(Date.now() + 36e5).toISOString(),
		size_vram: e.scale.params * 4
	})) };
}
function corsHeaders() {
	return {
		"Access-Control-Allow-Origin": "*",
		"Access-Control-Allow-Methods": "GET,POST,DELETE,HEAD,OPTIONS",
		"Access-Control-Allow-Headers": "Content-Type, Authorization, x-api-key"
	};
}
function json(data, status = 200) {
	return Response.json(data, {
		status,
		headers: corsHeaders()
	});
}
function streamNdjson(write) {
	const encoder = new TextEncoder();
	const stream = new ReadableStream({ async start(controller) {
		const emit = (obj) => {
			controller.enqueue(encoder.encode(JSON.stringify(obj) + "\n"));
		};
		try {
			await write(emit);
		} catch (err) {
			emit({ error: err instanceof Error ? err.message : String(err) });
		}
		controller.close();
	} });
	return new Response(stream, { headers: {
		...corsHeaders(),
		"Content-Type": "application/x-ndjson",
		"Cache-Control": "no-cache",
		"X-Accel-Buffering": "no"
	} });
}
async function handleGenerate(body) {
	const { ensureLoaded } = await import("./runtime-DqGp884e.mjs").then((n) => n.c);
	const eng = ensureLoaded(body.model ?? "metatron:ultra");
	const tokens = [];
	const organs = [];
	return {
		eng,
		text: eng.generate({
			prompt: body.prompt ?? "",
			temperature: body.options?.temperature ?? .7,
			topK: body.options?.top_k ?? 24,
			maxNew: body.options?.num_predict ?? 96,
			onToken: (tok, pulse) => {
				tokens.push(tok);
				organs.push(pulse);
			}
		}),
		tokens,
		organs
	};
}
async function handleChat(body) {
	const { ensureLoaded } = await import("./runtime-DqGp884e.mjs").then((n) => n.c);
	const eng = ensureLoaded(body.model ?? "metatron:ultra");
	const tokens = [];
	return {
		eng,
		text: eng.chat(body.messages ?? [], {
			temperature: body.options?.temperature ?? .7,
			topK: body.options?.top_k ?? 24,
			onToken: (tok) => tokens.push(tok)
		}),
		tokens,
		organs: eng.lastOrgans
	};
}
function openaiModels() {
	return {
		object: "list",
		data: listLibrary().map((e) => ({
			id: e.alias ?? e.scale.tag,
			object: "model",
			created: Math.floor(Date.now() / 1e3),
			owned_by: "metatron"
		}))
	};
}
async function handleOllama(request, splat) {
	const path = splat.replace(/^\/+/, "").replace(/\/+$/, "");
	const method = request.method.toUpperCase();
	if (method === "OPTIONS") return new Response(null, {
		status: 204,
		headers: corsHeaders()
	});
	if ((path === "tags" || path === "api/tags") && method === "GET") return json(tagsPayload());
	if ((path === "version" || path === "api/version") && (method === "GET" || method === "HEAD")) return json({ version: "0.12.metatron" });
	if ((path === "ps" || path === "api/ps") && method === "GET") return json(psPayload());
	if ((path === "models" || path === "v1/models" || path === "api/v1/models") && method === "GET") return json(openaiModels());
	const body = method === "GET" || method === "HEAD" ? {} : await request.json().catch(() => ({}));
	if (path === "show" && method === "POST") return json(showPayload(String(body.name ?? body.model ?? "metatron:ultra")));
	if (path === "pull" && method === "POST") {
		const name = String(body.name ?? body.model ?? "metatron:ultra");
		if (!(body.stream !== false)) {
			await pullModel(name, () => void 0);
			return json({
				status: "success",
				digest: getEngine(name).scale.digest
			});
		}
		return streamNdjson(async (emit) => {
			await pullModel(name, emit);
		});
	}
	if (path === "create" && method === "POST") {
		const model = String(body.model ?? body.name ?? "metatron:custom");
		const modelfile = String(body.modelfile ?? "");
		const stream = body.stream !== false;
		const run = async (emit) => {
			emit({ status: "parsing modelfile" });
			await sleep(40);
			const created = createFromModelfile(model, modelfile);
			emit({ status: `using FROM ${created.scale.tag}` });
			await pullModel(created.tag, emit);
		};
		if (!stream) {
			await run(() => void 0);
			return json({ status: "success" });
		}
		return streamNdjson(run);
	}
	if (path === "copy" && method === "POST") {
		const source = String(body.source ?? "");
		const destination = String(body.destination ?? "");
		if (!source || !destination) return json({ error: "source and destination required" }, 400);
		copyModel(source, destination);
		return json({});
	}
	if (path === "delete" && (method === "DELETE" || method === "POST")) {
		const name = String(body.name ?? body.model ?? "");
		if (!name) return json({ error: "model required" }, 400);
		const ok = deleteModel(name);
		return json(ok ? {} : { error: "model not found" }, ok ? 200 : 404);
	}
	if ((path === "embed" || path === "embeddings") && method === "POST") {
		const b = body;
		const eng = getEngine(b.model ?? "metatron:ultra");
		const embeddings = (Array.isArray(b.input) ? b.input : [b.input ?? b.prompt ?? ""]).map((t) => eng.embedText(String(t)));
		return json({
			model: eng.scale.tag,
			embeddings
		});
	}
	if (path === "generate" && method === "POST") return generateResponse(body);
	if (path === "chat" && method === "POST") return chatResponse(body);
	if ((path === "v1/chat/completions" || path === "chat/completions" || path === "api/v1/chat/completions") && method === "POST") return openaiChat(body);
	if ((path === "metatron/train" || path === "train") && method === "POST") {
		const b = body;
		const logs = trainMore(b.model ?? "metatron:ultra", b.epochs ?? 4);
		const eng = getEngine(b.model ?? "metatron:ultra");
		return json({
			model: eng.scale.tag,
			logs,
			lastLoss: eng.lastLoss,
			trainedEpochs: eng.trainedEpochs,
			organs: eng.lastOrgans
		});
	}
	return json({ error: `unknown ollama path /${path}` }, 404);
}
async function generateResponse(body) {
	const stream = body.stream !== false;
	const { eng, text, tokens } = await handleGenerate({
		model: body.model,
		prompt: body.prompt,
		options: body.options
	});
	const base = {
		model: eng.alias ?? eng.scale.tag,
		created_at: nowIso(),
		done_reason: "stop",
		context: [],
		total_duration: 12e6,
		load_duration: 1e6,
		prompt_eval_count: String(body.prompt ?? "").length,
		eval_count: text.length,
		organs: eng.lastOrgans
	};
	if (!stream) return json({
		...base,
		response: text,
		done: true
	});
	return streamNdjson(async (emit) => {
		for (const tok of tokens) {
			emit({
				...base,
				response: tok,
				done: false
			});
			await sleep(12);
		}
		emit({
			...base,
			response: "",
			done: true
		});
	});
}
async function chatResponse(body) {
	const stream = body.stream !== false;
	const { eng, text, tokens } = await handleChat({
		model: body.model,
		messages: body.messages,
		options: body.options
	});
	const model = eng.alias ?? eng.scale.tag;
	if (!stream) return json({
		model,
		created_at: nowIso(),
		message: {
			role: "assistant",
			content: text
		},
		done: true,
		done_reason: "stop",
		total_duration: 14e6,
		eval_count: text.length,
		organs: eng.lastOrgans
	});
	return streamNdjson(async (emit) => {
		for (const tok of tokens) {
			emit({
				model,
				created_at: nowIso(),
				message: {
					role: "assistant",
					content: tok
				},
				done: false,
				organs: eng.lastOrgans
			});
			await sleep(12);
		}
		emit({
			model,
			created_at: nowIso(),
			message: {
				role: "assistant",
				content: ""
			},
			done: true,
			done_reason: "stop",
			organs: eng.lastOrgans
		});
	});
}
async function openaiChat(body) {
	const stream = body.stream === true;
	const { eng, text, tokens } = await handleChat({
		model: body.model,
		messages: body.messages
	});
	const model = eng.alias ?? eng.scale.tag;
	const id = `chatcmpl-metatron`;
	if (!stream) return json({
		id,
		object: "chat.completion",
		created: Math.floor(Date.now() / 1e3),
		model,
		choices: [{
			index: 0,
			message: {
				role: "assistant",
				content: text
			},
			finish_reason: "stop"
		}],
		usage: {
			prompt_tokens: 0,
			completion_tokens: tokens.length,
			total_tokens: tokens.length
		}
	});
	return streamNdjson(async (emit) => {
		for (const tok of tokens) {
			emit({
				id,
				object: "chat.completion.chunk",
				created: Math.floor(Date.now() / 1e3),
				model,
				choices: [{
					index: 0,
					delta: { content: tok },
					finish_reason: null
				}]
			});
			await sleep(12);
		}
		emit({
			id,
			object: "chat.completion.chunk",
			created: Math.floor(Date.now() / 1e3),
			model,
			choices: [{
				index: 0,
				delta: {},
				finish_reason: "stop"
			}]
		});
	});
}
var Route$1 = createFileRoute("/api/$")({ server: { handlers: {
	OPTIONS: async () => new Response(null, {
		status: 204,
		headers: corsHeaders()
	}),
	GET: async ({ params, request }) => handleOllama(request, params._splat ?? ""),
	POST: async ({ params, request }) => handleOllama(request, params._splat ?? ""),
	DELETE: async ({ params, request }) => handleOllama(request, params._splat ?? ""),
	HEAD: async ({ params, request }) => handleOllama(request, params._splat ?? "")
} } });
var Route = createFileRoute("/v1/$")({ server: { handlers: {
	OPTIONS: async () => new Response(null, {
		status: 204,
		headers: corsHeaders()
	}),
	GET: async ({ params, request }) => handleOllama(request, params._splat ?? ""),
	POST: async ({ params, request }) => handleOllama(request, params._splat ?? ""),
	HEAD: async ({ params, request }) => handleOllama(request, params._splat ?? "")
} } });
var rootRouteChildren = {
	IndexRoute: Route$2.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$3
	}),
	ApiSplatRoute: Route$1.update({
		id: "/api/$",
		path: "/api/$",
		getParentRoute: () => Route$3
	}),
	V1SplatRoute: Route.update({
		id: "/v1/$",
		path: "/v1/$",
		getParentRoute: () => Route$3
	})
};
var routeTree = Route$3._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { modelfileFor as n, openclawSnippet as r, router_exports as t };
