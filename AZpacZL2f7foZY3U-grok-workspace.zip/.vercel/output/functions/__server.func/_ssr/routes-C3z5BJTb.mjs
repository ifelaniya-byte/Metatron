import { i as __toESM } from "../_runtime.mjs";
import { d as SCALES, f as getScale, p as ORGANS } from "./runtime-DqGp884e.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as LoaderCircle, c as Copy, d as ArrowUp, f as Activity, i as MessageSquare, l as Circle, n as Terminal, o as Flower2, r as Radio, s as Download, u as Check } from "../_libs/lucide-react.mjs";
import { n as modelfileFor, r as openclawSnippet } from "./router-B8aSGbYo.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { a as ResponsiveContainer, i as Line, n as YAxis, o as Tooltip, r as XAxis, t as LineChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C3z5BJTb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
async function readNdjson(res, onLine) {
	if (!res.body) {
		const text = await res.text();
		for (const line of text.split("\n")) {
			if (!line.trim()) continue;
			onLine(JSON.parse(line));
		}
		return;
	}
	const reader = res.body.getReader();
	const dec = new TextDecoder();
	let buf = "";
	for (;;) {
		const { done, value } = await reader.read();
		if (done) break;
		buf += dec.decode(value, { stream: true });
		const lines = buf.split("\n");
		buf = lines.pop() ?? "";
		for (const line of lines) {
			if (!line.trim()) continue;
			onLine(JSON.parse(line));
		}
	}
	if (buf.trim()) onLine(JSON.parse(buf));
}
async function fetchTags() {
	const res = await fetch("/api/tags");
	if (!res.ok) throw new Error(`tags ${res.status}`);
	return (await res.json()).models ?? [];
}
async function fetchPs() {
	const res = await fetch("/api/ps");
	if (!res.ok) throw new Error(`ps ${res.status}`);
	return (await res.json()).models ?? [];
}
async function fetchVersion() {
	const res = await fetch("/api/version");
	if (!res.ok) return "unknown";
	return (await res.json()).version ?? "unknown";
}
async function pullModel(name, onLine) {
	const res = await fetch("/api/pull", {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			name,
			stream: true
		})
	});
	if (!res.ok) throw new Error(`pull ${res.status}`);
	await readNdjson(res, (obj) => {
		const status = String(obj.status ?? "");
		const total = Number(obj.total ?? 0);
		const completed = Number(obj.completed ?? 0);
		if (total && obj.completed != null) onLine(`${status}  ${Math.min(100, Math.round(completed / total * 100))}%`, obj);
		else onLine(status, obj);
	});
}
async function chatStream(model, messages, onTok) {
	const res = await fetch("/api/chat", {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			model,
			messages,
			stream: true
		})
	});
	if (!res.ok) throw new Error(`chat ${res.status}`);
	let full = "";
	await readNdjson(res, (obj) => {
		const piece = obj.message?.content ?? "";
		const organs = obj.organs;
		if (obj.done === true) {
			if (organs) onTok("", organs);
			return;
		}
		if (piece) {
			full += piece;
			onTok(piece, organs);
		}
	});
	return full;
}
async function trainModel(model, epochs) {
	const res = await fetch("/api/metatron/train", {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			model,
			epochs
		})
	});
	if (!res.ok) throw new Error(`train ${res.status}`);
	return await res.json();
}
var booted = false;
var useApp = create((set, get) => ({
	scaleId: "ultra",
	pulling: true,
	pullLog: [">>> ollama pull metatron:ultra"],
	ready: false,
	messages: [],
	input: "",
	streaming: false,
	organs: [],
	tab: "organs",
	trainLogs: [],
	training: false,
	loadedIds: [],
	version: "",
	error: null,
	setInput: (v) => set({ input: v }),
	setTab: (t) => set({ tab: t }),
	scale: () => SCALES.find((s) => s.id === get().scaleId) ?? SCALES[1],
	boot: async () => {
		if (booted) return;
		booted = true;
		await get().loadScale("ultra");
	},
	loadScale: async (id) => {
		set({
			scaleId: id,
			pulling: true,
			pullLog: [`>>> ollama pull metatron:${id}`],
			ready: false,
			error: null
		});
		try {
			await pullModel(`metatron:${id}`, (line, raw) => {
				const done = String(raw.status ?? "") === "success";
				set((s) => ({
					pullLog: [...s.pullLog, line],
					pulling: done ? false : s.pulling,
					ready: done ? true : s.ready
				}));
			});
			const loadedIds = uniqueIds((await fetchPs().catch(() => [])).map((m) => tagToId(m.name)));
			const scale = SCALES.find((s) => s.id === id) ?? SCALES[1];
			set((s) => ({
				pulling: false,
				ready: true,
				loadedIds: loadedIds.length ? loadedIds : s.loadedIds.includes(id) ? s.loadedIds : [...s.loadedIds, id],
				messages: [{
					id: "sys-loaded",
					role: "system",
					content: `metatron:${id} loaded · ${scale.sizeLabel} params · ${scale.modules} modules · ctx ${scale.ctx}`
				}]
			}));
		} catch (err) {
			set({
				pulling: false,
				ready: false,
				error: err instanceof Error ? err.message : "pull failed",
				pullLog: [...get().pullLog, `error: ${err instanceof Error ? err.message : "pull failed"}`]
			});
		}
	},
	send: async (text) => {
		const raw = (text ?? get().input).trim();
		if (!raw || get().streaming || get().pulling) return;
		const user = {
			id: uid(),
			role: "user",
			content: raw
		};
		const asstId = uid();
		set((s) => ({
			input: "",
			streaming: true,
			messages: [
				...s.messages,
				user,
				{
					id: asstId,
					role: "assistant",
					content: ""
				}
			]
		}));
		const history = get().messages.filter((m) => (m.role === "user" || m.role === "assistant") && m.id !== asstId && m.content).map((m) => ({
			role: m.role,
			content: m.content
		}));
		try {
			const reply = await chatStream(`metatron:${get().scaleId}`, history, (tok, organs) => {
				set((s) => ({
					organs: organs ?? s.organs,
					messages: s.messages.map((m) => m.id === asstId ? {
						...m,
						content: tok ? m.content + tok : m.content,
						organs
					} : m)
				}));
			});
			set((s) => ({
				streaming: false,
				messages: s.messages.map((m) => m.id === asstId ? {
					...m,
					content: m.content || reply
				} : m)
			}));
		} catch (err) {
			set((s) => ({
				streaming: false,
				error: err instanceof Error ? err.message : "chat failed",
				messages: s.messages.map((m) => m.id === asstId ? {
					...m,
					content: m.content || "The runtime could not complete that turn."
				} : m)
			}));
		}
	},
	train: async (epochs) => {
		if (get().training || get().pulling || !get().ready) return;
		set({
			training: true,
			tab: "train"
		});
		try {
			const result = await trainModel(`metatron:${get().scaleId}`, epochs);
			set((s) => ({
				training: false,
				trainLogs: [...s.trainLogs, ...result.logs],
				organs: result.organs ?? s.organs
			}));
		} catch {
			set({ training: false });
		}
	}
}));
function uid() {
	return Math.random().toString(36).slice(2, 10);
}
function tagToId(tag) {
	if (tag.includes("nano")) return "nano";
	if (tag.includes("tiny")) return "tiny";
	return "ultra";
}
function uniqueIds(ids) {
	return [...new Set(ids)];
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[opacity,transform,background-color,color] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50 disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-fg text-bg hover:opacity-90",
			accent: "bg-accent text-accent-fg hover:opacity-90",
			outline: "border border-border bg-transparent text-fg hover:bg-raised",
			ghost: "text-muted hover:text-fg hover:bg-raised",
			subtle: "bg-raised text-fg hover:bg-line"
		},
		size: {
			default: "h-10 rounded-md px-3.5 text-sm",
			sm: "h-8 rounded-sm px-2.5 text-xs",
			lg: "h-11 rounded-md px-4 text-sm",
			icon: "size-10 rounded-md",
			"icon-sm": "size-8 rounded-sm"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		ref,
		...props
	});
});
Button.displayName = "Button";
var SUGGESTIONS = [
	"Who are you?",
	"How does the Flower of Life work?",
	"How do I load you in Ollama?",
	"the flower of life is"
];
function ChatConsole() {
	const messages = useApp((s) => s.messages);
	const input = useApp((s) => s.input);
	const setInput = useApp((s) => s.setInput);
	const send = useApp((s) => s.send);
	const streaming = useApp((s) => s.streaming);
	const pulling = useApp((s) => s.pulling);
	const pullLog = useApp((s) => s.pullLog);
	const ready = useApp((s) => s.ready);
	const scaleId = useApp((s) => s.scaleId);
	const error = useApp((s) => s.error);
	const scroller = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		scroller.current?.scrollTo({
			top: scroller.current.scrollHeight,
			behavior: "smooth"
		});
	}, [
		messages,
		pullLog,
		streaming
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex min-h-0 min-w-0 flex-1 flex-col bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex h-12 shrink-0 items-center justify-between border-b border-border px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-xs text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-subtle",
							children: "$"
						}),
						" ollama run ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-fg",
							children: ["metatron:", scaleId]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("size-1.5 rounded-full", ready && !pulling ? "bg-ok" : "bg-muted animate-pulse"),
					"aria-label": ready ? "loaded" : "loading"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: scroller,
				className: "min-h-0 flex-1 overflow-y-auto px-4 py-4",
				children: [
					pullLog.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "mb-6 whitespace-pre-wrap font-mono text-xs leading-6 text-muted",
						children: pullLog.join("\n")
					}) : null,
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-4 font-mono text-xs text-danger",
						children: error
					}) : null,
					messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
						className: "mb-4",
						children: m.role === "system" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs text-subtle",
							children: m.content
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-0.5 w-16 shrink-0 font-mono text-3xs uppercase tracking-wider text-subtle",
								children: m.role === "user" ? "you" : "metatron"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: cn("max-w-[62ch] text-sm leading-relaxed text-pretty", m.role === "user" ? "text-muted" : "text-fg"),
								children: m.content || (streaming ? "…" : "")
							})]
						})
					}, m.id)),
					ready && messages.filter((m) => m.role !== "system").length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: SUGGESTIONS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => void send(s),
							className: "min-h-11 rounded-md border border-border bg-surface px-3 py-2 text-left text-xs text-muted transition-colors duration-[var(--motion-quick)] hover:border-line hover:text-fg",
							children: s
						}, s))
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
				className: "shrink-0 border-t border-border p-3",
				onSubmit: (e) => {
					e.preventDefault();
					send();
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-end gap-2 rounded-lg bg-surface p-1.5 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						rows: 1,
						value: input,
						disabled: !ready || streaming,
						placeholder: pulling ? "Waiting for pull…" : "Send a message",
						onChange: (e) => setInput(e.target.value),
						onKeyDown: (e) => {
							if (e.key === "Enter" && !e.shiftKey) {
								e.preventDefault();
								send();
							}
						},
						className: "max-h-32 min-h-11 flex-1 resize-none bg-transparent px-3 py-2 font-sans text-sm text-fg outline-none placeholder:text-subtle"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						size: "icon",
						disabled: !ready || streaming || !input.trim(),
						"aria-label": "Send",
						children: streaming ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, {})
					})]
				})
			})
		]
	});
}
var badgeVariants = cva("inline-flex items-center rounded-full px-2 py-0.5 text-2xs font-medium tracking-wide", {
	variants: { variant: {
		default: "bg-raised text-muted",
		ok: "bg-ok/15 text-ok",
		accent: "bg-accent/15 text-accent",
		outline: "border border-border text-muted"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
function ModelRail() {
	const scaleId = useApp((s) => s.scaleId);
	const ready = useApp((s) => s.ready);
	const pulling = useApp((s) => s.pulling);
	const loadedIds = useApp((s) => s.loadedIds);
	const loadScale = useApp((s) => s.loadScale);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "flex h-full min-h-0 w-full flex-col border-r border-border bg-surface",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-3xs uppercase tracking-widest text-subtle",
					children: "Library"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-0.5 text-sm font-medium text-fg",
					children: "Local models"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "outline",
					children: SCALES.length
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex min-h-0 flex-1 flex-col gap-1 overflow-y-auto px-2 pb-3",
				children: SCALES.map((m) => {
					const loaded = loadedIds.includes(m.id);
					const active = scaleId === m.id && ready;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: pulling,
						onClick: () => void loadScale(m.id),
						className: cn("flex min-h-11 w-full items-start gap-3 rounded-md px-3 py-2.5 text-left transition-colors duration-[var(--motion-quick)]", active ? "bg-raised" : "hover:bg-raised/70"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 text-accent",
							children: active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : loaded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "size-3.5 fill-ok/80 text-ok" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5 text-subtle" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-baseline justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate font-mono text-sm text-fg",
									children: m.tag
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-3xs tabular-nums text-subtle",
									children: m.sizeLabel
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-0.5 block text-xs text-muted",
								children: [
									m.modules,
									" modules · dim ",
									m.dim,
									" · ctx ",
									m.ctx
								]
							})]
						})]
					}) }, m.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-border px-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-3xs leading-relaxed text-subtle",
					children: [
						"ollama pull metatron:ultra",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						"ollama run metatron:ultra"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "accent",
					size: "sm",
					className: "mt-2 min-h-11 w-full",
					disabled: pulling,
					onClick: () => void loadScale(scaleId),
					children: ready ? "Reload into Ollama" : "Load into Ollama"
				})]
			})
		]
	});
}
var R = 18;
var CX = 140;
var CY = 132;
function hexRing(n, radius) {
	if (n === 0) return [{
		x: CX,
		y: CY
	}];
	const pts = [];
	for (let i = 0; i < 6; i++) {
		const a = Math.PI / 3 * i - Math.PI / 6;
		const x0 = CX + radius * Math.cos(a);
		const y0 = CY + radius * Math.sin(a);
		if (n === 1) pts.push({
			x: x0,
			y: y0
		});
		else {
			const a2 = a + Math.PI / 3;
			for (let k = 0; k < n; k++) pts.push({
				x: x0 + radius * k / n * Math.cos(a2),
				y: y0 + radius * k / n * Math.sin(a2)
			});
		}
	}
	return pts;
}
var NODES = [
	...hexRing(0, 0),
	...hexRing(1, 36),
	...hexRing(2, 72)
].slice(0, 19);
var ORGAN_AT = {
	brain: 0,
	memory: 3,
	ears: 6,
	mouth: 9,
	hands: 12,
	heart: 15,
	legs: 1
};
function FlowerOfLife({ pulses, modules: _modules = 13, className }) {
	const act = new Map(pulses.map((p) => [p.id, p.activation]));
	const nodeAct = NODES.map((_, i) => {
		const organ = ORGANS.find((o) => ORGAN_AT[o.id] === i);
		if (organ) return act.get(organ.id) ?? .1;
		return .08 + i * 13 % 7 * .02;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 280 264",
		className: cn("h-auto w-full", className),
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: CX,
				cy: CY,
				r: R * 5.4,
				fill: "none",
				stroke: "currentColor",
				strokeOpacity: .06
			}),
			NODES.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: p.x,
				cy: p.y,
				r: R,
				fill: "none",
				stroke: "currentColor",
				strokeOpacity: .18 + nodeAct[i] * .35,
				strokeWidth: 1
			}, `c-${i}`)),
			NODES.map((p, i) => {
				const organ = ORGANS.find((o) => ORGAN_AT[o.id] === i);
				const a = nodeAct[i];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: p.x,
					cy: p.y,
					r: 3.4 + a * 2.4,
					fill: organ ? "var(--color-accent)" : "var(--color-fg)",
					fillOpacity: .25 + a * .75
				}), organ ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: p.x,
					y: p.y + 16,
					textAnchor: "middle",
					className: "fill-muted",
					fontSize: "7",
					fontFamily: "var(--font-sans)",
					children: organ.title
				}) : null] }, `n-${i}`);
			})
		]
	});
}
var TABS = [
	{
		id: "organs",
		label: "Organs",
		icon: Flower2
	},
	{
		id: "train",
		label: "Train",
		icon: Activity
	},
	{
		id: "connect",
		label: "Connect",
		icon: Radio
	}
];
function SidePanel() {
	const tab = useApp((s) => s.tab);
	const setTab = useApp((s) => s.setTab);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "flex h-full min-h-0 w-full flex-col border-l border-border bg-surface",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "flex shrink-0 border-b border-border",
			children: TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setTab(t.id),
				className: cn("flex min-h-11 flex-1 items-center justify-center gap-1.5 py-3 text-xs font-medium uppercase tracking-wider transition-colors duration-[var(--motion-quick)]", tab === t.id ? "text-fg" : "text-subtle hover:text-muted"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(t.icon, { className: "size-3.5" }), t.label]
			}, t.id))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-h-0 flex-1 overflow-y-auto p-4",
			children: [
				tab === "organs" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrgansPane, {}) : null,
				tab === "train" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrainPane, {}) : null,
				tab === "connect" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConnectPane, {}) : null
			]
		})]
	});
}
function OrgansPane() {
	const organs = useApp((s) => s.organs);
	const scaleId = useApp((s) => s.scaleId);
	const scale = getScale(scaleId);
	const act = new Map(organs.map((o) => [o.id, o.activation]));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlowerOfLife, {
		pulses: organs,
		modules: scale.modules,
		className: "text-fg"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-2 space-y-2",
		children: ORGANS.map((o) => {
			const a = act.get(o.id) ?? 0;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-md bg-raised px-3 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium text-fg",
							children: o.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-mono text-3xs tabular-nums text-subtle",
							children: [Math.round(a * 100), "%"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1.5 h-0.5 overflow-hidden rounded-full bg-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-accent transition-[width] duration-[var(--motion-fast)] ease-[var(--ease-out)]",
							style: { width: `${Math.round(a * 100)}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1.5 text-xs leading-snug text-muted",
						children: o.role
					})
				]
			}, o.id);
		})
	})] });
}
function TrainPane() {
	const logs = useApp((s) => s.trainLogs);
	const training = useApp((s) => s.training);
	const train = useApp((s) => s.train);
	const ready = useApp((s) => s.ready);
	const last = logs[logs.length - 1];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-end justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-3xs uppercase tracking-widest text-subtle",
				children: "Loss"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-lg tabular-nums text-fg",
				children: last ? last.loss.toFixed(3) : "—"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				variant: training ? "accent" : "outline",
				children: training ? "running" : "idle"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-36 rounded-md bg-raised p-2",
			children: logs.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
				width: "100%",
				height: "100%",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
					data: logs,
					margin: {
						top: 8,
						right: 8,
						left: -20,
						bottom: 0
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
							dataKey: "epoch",
							tick: {
								fill: "var(--color-subtle)",
								fontSize: 10
							},
							axisLine: false,
							tickLine: false
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
							tick: {
								fill: "var(--color-subtle)",
								fontSize: 10
							},
							axisLine: false,
							tickLine: false,
							domain: ["auto", "auto"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
							background: "var(--color-surface)",
							border: "1px solid var(--color-border)",
							fontSize: 11,
							color: "var(--color-fg)"
						} }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							type: "monotone",
							dataKey: "loss",
							stroke: "var(--color-accent)",
							strokeWidth: 1.5,
							dot: false
						})
					]
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "flex h-full items-center justify-center text-xs text-subtle",
				children: "Pull a model to seed the curve"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 grid grid-cols-3 gap-2",
			children: [
				4,
				8,
				16
			].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				size: "sm",
				className: "min-h-11",
				disabled: !ready || training,
				onClick: () => void train(n),
				children: [n, " ep"]
			}, n))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-xs leading-relaxed text-muted",
			children: "More epochs jam the geometric core into the corpus. The skeleton stays the same size."
		})
	] });
}
function ConnectPane() {
	const scaleId = useApp((s) => s.scaleId);
	const ready = useApp((s) => s.ready);
	const scale = getScale(scaleId);
	const origin = typeof window !== "undefined" ? window.location.origin : "https://this-runtime";
	const file = modelfileFor(scale);
	const claw = openclawSnippet(scale, origin);
	const [probe, setProbe] = (0, import_react.useState)("idle — click Probe");
	const [probing, setProbing] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (ready) runProbe(setProbe);
	}, [ready]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-1.5 flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium text-fg",
					children: "Live Ollama API"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					disabled: probing,
					onClick: () => void runProbe(setProbe, setProbing),
					children: "Probe"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "max-h-40 overflow-auto rounded-md bg-raised p-3 font-mono text-3xs leading-relaxed text-muted",
				children: probe
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-1.5 flex items-center gap-2 text-xs font-medium text-fg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Terminal, { className: "size-3.5 text-muted" }), "Modelfile"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyBlock, { text: file })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1.5 text-xs font-medium text-fg",
					children: "OpenClaw / Open WebUI"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-2 text-xs leading-relaxed text-muted",
					children: [
						"This app is the Ollama host. Point the provider at this origin and set primary to ollama/",
						scale.tag,
						". Native routes live under /api; OpenAI-compatible under /v1."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyBlock, { text: claw })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-1.5 text-xs font-medium text-fg",
				children: "Ollama API"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "space-y-1 font-mono text-xs text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "GET /api/tags" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "GET /api/ps" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "POST /api/pull" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "POST /api/show" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "POST /api/generate" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "POST /api/chat" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "POST /api/create" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "GET /v1/models" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "POST /v1/chat/completions" })
				]
			})] })
		]
	});
}
async function runProbe(setProbe, setProbing) {
	setProbing?.(true);
	try {
		const [version, tags, ps] = await Promise.all([
			fetchVersion(),
			fetchTags(),
			fetchPs()
		]);
		setProbe([
			`GET /api/version  ${version}`,
			`GET /api/tags     ${tags.length} models`,
			...tags.map((t) => `  - ${t.name}  ${t.details?.parameter_size ?? ""}`),
			`GET /api/ps       ${ps.length} loaded`,
			...ps.map((t) => `  - ${t.name}`)
		].join("\n"));
	} catch (err) {
		setProbe(`probe failed: ${err instanceof Error ? err.message : "error"}`);
	} finally {
		setProbing?.(false);
	}
}
function CopyBlock({ text }) {
	const [copied, setCopied] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative rounded-md bg-raised",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				size: "icon-sm",
				className: "absolute right-1 top-1",
				"aria-label": "Copy",
				onClick: async () => {
					try {
						await navigator.clipboard.writeText(text);
						setCopied(true);
						setTimeout(() => setCopied(false), 1400);
					} catch {
						setCopied(false);
					}
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "max-h-48 overflow-auto p-3 pr-9 font-mono text-3xs leading-relaxed text-muted",
				children: text
			}),
			copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute bottom-2 right-2 font-mono text-3xs text-ok",
				children: "copied"
			}) : null
		]
	});
}
function Home() {
	const boot = useApp((s) => s.boot);
	const ready = useApp((s) => s.ready);
	const pulling = useApp((s) => s.pulling);
	const scaleId = useApp((s) => s.scaleId);
	const tab = useApp((s) => s.tab);
	const setTab = useApp((s) => s.setTab);
	const [pane, setPane] = (0, import_react.useState)("chat");
	(0, import_react.useEffect)(() => {
		boot();
	}, [boot]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex h-[100dvh] flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex h-12 shrink-0 items-center justify-between border-b border-border px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-sm font-semibold tracking-tight text-fg",
						children: "Metatron"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-3xs uppercase tracking-widest text-subtle",
						children: "Ollama runtime"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "hidden font-mono text-xs text-muted sm:block",
					children: ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["loaded ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-fg",
						children: ["metatron:", scaleId]
					})] }) : pulling ? "pulling…" : "idle"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("h-full shrink-0", pane === "models" ? "flex w-full md:w-[260px]" : "hidden md:flex md:w-[260px]"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModelRail, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("min-h-0 min-w-0 flex-1 flex-col", pane === "chat" ? "flex" : "hidden md:flex"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatConsole, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("h-full shrink-0", pane === "side" ? "flex w-full lg:w-[300px]" : "hidden lg:flex lg:w-[300px]"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidePanel, {})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "flex shrink-0 border-t border-border lg:hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTab, {
						label: "Models",
						icon: Flower2,
						active: pane === "models",
						onClick: () => setPane("models")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTab, {
						label: "Run",
						icon: MessageSquare,
						active: pane === "chat",
						onClick: () => setPane("chat")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTab, {
						label: "Train",
						icon: Activity,
						active: pane === "side" && tab === "train",
						onClick: () => {
							setTab("train");
							setPane("side");
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTab, {
						label: "API",
						icon: Radio,
						active: pane === "side" && tab === "connect",
						onClick: () => {
							setTab("connect");
							setPane("side");
						}
					})
				]
			})
		]
	});
}
function MobileTab({ label, icon: Icon, active, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("flex h-12 flex-1 flex-col items-center justify-center gap-0.5 text-3xs uppercase tracking-wider", active ? "text-fg" : "text-subtle"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), label]
	});
}
function Mark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: "22",
		height: "22",
		viewBox: "0 0 22 22",
		"aria-hidden": "true",
		className: "text-accent",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "11",
				cy: "11",
				r: "3.2",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "11",
				cy: "7.2",
				r: "3.2",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "14.3",
				cy: "9.1",
				r: "3.2",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "14.3",
				cy: "12.9",
				r: "3.2",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "11",
				cy: "14.8",
				r: "3.2",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "7.7",
				cy: "12.9",
				r: "3.2",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "7.7",
				cy: "9.1",
				r: "3.2",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.2"
			})
		]
	});
}
//#endregion
export { Home as component };
