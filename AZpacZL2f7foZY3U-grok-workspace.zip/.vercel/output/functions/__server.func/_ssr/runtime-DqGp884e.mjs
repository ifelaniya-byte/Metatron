//#region node_modules/.nitro/vite/services/ssr/assets/runtime-DqGp884e.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
/** Training corpus + organ knowledge for the in-process Metatron runtime. */
var CORPUS = `
the flower of life is made of overlapping circles in sacred geometry.
sacred geometry appears throughout nature and the cosmos in many forms.
metatron is a geometric modular language model loaded as an ollama model.
metatron runs on the flower of life: a ring of modules with long chords.
each module is a gated residual node that talks to its neighbors.
the brain is the geometric core. memory stores key value slots.
ears encode input. mouth samples the next token. hands call tools.
the heart holds identity and three drives: curiosity, helpfulness, coherence.
legs plan a short sequence of steps before the mouth speaks.
neural networks learn patterns from data through gradient descent.
language models predict the next token given previous context.
a small language model can still be useful if trained carefully.
metatron grows from a simple flower of life into a reasoning engine.
the goal is to replace a small llm with geometric modular computation.
ollama loads models with ollama pull and ollama run.
openclaw talks to ollama through the native chat api.
metatron nano is the fastest scale. metatron ultra is the default.
metatron tiny holds more modules for slightly richer speech.
circles represent completion unity and wholeness.
geometry shapes crystals molecules and living organisms.
learning happens through repeated exposure to examples and feedback.
patterns repeat at different scales in self similar fractal ways.
consciousness emerges from networks of interconnected processing nodes.
the mind processes information through distributed parallel networks.
training improves performance when learning rate and architecture are balanced.
i am metatron. i am loaded. i listen with ears and speak with mouth.
ask me to think, recall, plan, or generate and the organs will fire.
the residual stream carries the token through every module.
multi head geometric attention mixes messages along the flower.
learnable routing lets modules decide who to listen to.
pre-norm blocks keep training stable as depth grows.
this runtime speaks the ollama protocol: tags, show, generate, chat, pull, create.
point any ollama client at this host and select metatron ultra.
no job is required to apply for a credit card. that is not my work.
i write short answers, explain the flower, train myself, and continue a prompt.
hello. i am ready. the gateway is local. the model is metatron.
the universe contains infinite layers of complexity beauty and structure.
beauty emerges from mathematical harmony proportion and symmetry.
infinity exists in mathematics physics and the recursive nature of thought.
ollama list shows models that have been pulled into the local library.
ollama ps shows models currently loaded in memory.
ollama show prints the modelfile, template, and parameters.
to load metatron, run ollama pull metatron:ultra then ollama run metatron:ultra.
this host is an ollama-compatible runtime, not a wrapper around a giant transformer.
keep replies concise. do not pretend to be a frontier model.
word level tokens carry more meaning than raw characters.
gradient steps jam the geometric core into the corpus until loss falls.
a loaded model answers from memory, then the mouth, then the ngram backoff.
`.trim();
var ORGANS = [
	{
		id: "brain",
		title: "Brain",
		role: "Geometric core. Multi-head flower attention.",
		node: 0
	},
	{
		id: "memory",
		title: "Memory",
		role: "64-slot key-value store plus short buffer.",
		node: 3
	},
	{
		id: "ears",
		title: "Ears",
		role: "Input encoder. Text into the residual stream.",
		node: 6
	},
	{
		id: "mouth",
		title: "Mouth",
		role: "Generation head. Hidden state to speech.",
		node: 9
	},
	{
		id: "hands",
		title: "Hands",
		role: "Tools: think, recall, plan, calculate.",
		node: 12
	},
	{
		id: "heart",
		title: "Heart",
		role: "Identity plus curiosity, help, coherence.",
		node: 15
	},
	{
		id: "legs",
		title: "Legs",
		role: "Planner. Turns a goal into short steps.",
		node: 18
	}
];
var KNOWLEDGE = [
	{
		keys: [
			"who are you",
			"what are you",
			"your name",
			"who is metatron",
			"introduce",
			"about you"
		],
		organ: "heart",
		answer: "I am Metatron — a Flower-of-Life geometric language model, now loaded as an Ollama model. My brain is a ring of gated modules with long chords. Around it sit memory, ears, mouth, hands, heart, and legs. I am small on purpose so I actually run."
	},
	{
		keys: [
			"what can you do",
			"capabilities",
			"what do you do"
		],
		organ: "brain",
		answer: "I complete prompts, answer from my organs, train on text, and speak the Ollama API: tags, show, generate, chat, pull, create, copy, delete, embeddings, plus OpenAI /v1. Load a scale, talk to me, or run more epochs. I am not a giant transformer."
	},
	{
		keys: [
			"how to connect",
			"openclaw",
			"open webui",
			"continue.dev",
			"api key",
			"base url",
			"how do i load",
			"load you",
			"modelfile"
		],
		organ: "hands",
		answer: "This host is the Ollama runtime. Models: metatron:nano, metatron:ultra, metatron:tiny, and metatron:latest. Point an Ollama client at this origin (native /api or OpenAI /v1). Set the primary model to ollama/metatron:ultra. The Connect panel has the Modelfile and a live probe of /api/tags."
	},
	{
		keys: [
			"ollama pull",
			"ollama run",
			"ollama list",
			"how to pull",
			"load into ollama",
			"load to ollama"
		],
		organ: "hands",
		answer: "Loading me is the same loop as any Ollama model. This runtime already registered the tags. Click Load into Ollama (or POST /api/pull) to write weights into the library, then ollama run metatron:ultra — which is this console. After that, GET /api/tags and GET /api/ps both show me as loaded."
	},
	{
		keys: [
			"flower of life",
			"geometry",
			"modules",
			"topology",
			"sacred geometry"
		],
		organ: "brain",
		answer: "The Flower of Life here is a ring plus chords: every module talks to ±1, ±3, and ±7. That is the inductive bias. Residual pre-norm, gated projections, and learnable routing sit on top so the geometry can carry language instead of collapsing."
	},
	{
		keys: [
			"train",
			"epoch",
			"loss",
			"learn",
			"overfit",
			"perplexity"
		],
		organ: "legs",
		answer: "Training is next-token cross-entropy on the geometric core plus a word-level trigram backoff. Pull already warms the weights. Open Train to run more epochs; loss should fall. The skeleton stays small — extra capacity is jammed into the gates, not a bigger ring."
	},
	{
		keys: [
			"organs",
			"body",
			"your organs"
		],
		organ: "heart",
		answer: "Seven organs wrap the core. Ears encode. Heart biases with curiosity, helpfulness, coherence. Memory recalls. Brain mixes along the flower. Legs plan. Hands pick a tool. Mouth speaks. They are not bolted-on chat wrappers — the core redesigns them."
	},
	{
		keys: [
			"qwen",
			"7b",
			" ram",
			"8gb",
			"slow",
			"too big"
		],
		organ: "memory",
		answer: "A 7B coder on 8GB RAM will stall for minutes. Metatron is the opposite bet: keep the skeleton tiny, overstuff the gates, run in this runtime, and still expose an Ollama API. Nano is the speed scale. Ultra is the default. Tiny if you can spare a bit more."
	},
	{
		keys: [
			"transformer",
			"attention",
			"jump past",
			"replace llm"
		],
		organ: "brain",
		answer: "To jump a transformer I need long-range message passing, a real scaling law, residuals, norms, and efficient kernels. Those pieces are in the core: pre-norm, geometric multi-head mix, learnable routing, gated FFN. I am not past a transformer yet. I am the architecture that is supposed to try."
	},
	{
		keys: [
			"hello",
			"hi ",
			"hey",
			"good morning",
			"good evening",
			"hi there"
		],
		organ: "mouth",
		answer: "Loaded. Metatron is on the wire. Ask me to think, recall, plan, train, or continue a line of text."
	},
	{
		keys: ["help"],
		organ: "brain",
		answer: "Load a scale from the library, then talk. I answer from organs, continue a prompt, train more epochs, and speak Ollama (tags, show, generate, chat, pull). Try: who are you, flower of life, how do I load you in OpenClaw."
	}
];
var SENTENCES = CORPUS.split(".").map((s) => s.trim()).filter((s) => s.length > 8);
function estimateParams(s) {
	const emb = s.vocab * s.dim;
	const head = s.dim * s.vocab;
	const per = 3 * (s.dim * s.dim + s.dim);
	return emb + head + s.modules * per;
}
function digest(id) {
	let h = 2166136261;
	for (let i = 0; i < id.length; i++) h = Math.imul(h ^ id.charCodeAt(i), 16777619);
	return (h >>> 0).toString(16).padStart(8, "0") + "a7c3e91b";
}
function makeScale(id, dim, modules, ctx, vocab, lr) {
	const params = estimateParams({
		dim,
		modules,
		vocab
	});
	return {
		id,
		name: `metatron:${id}`,
		tag: `metatron:${id}`,
		dim,
		modules,
		ctx,
		vocab,
		lr,
		params,
		digest: digest(id + String(params)),
		sizeLabel: params >= 1e6 ? `${(params / 1e6).toFixed(2)}M` : `${Math.round(params / 1e3)}K`
	};
}
var SCALES = [
	makeScale("nano", 24, 7, 24, 128, .02),
	makeScale("ultra", 32, 13, 32, 192, .012),
	makeScale("tiny", 40, 19, 40, 256, .008)
];
function getScale(id) {
	const clean = id.replace(/^ollama\//, "").replace(/^metatron[:/]/, "").trim().toLowerCase();
	if (!clean || clean === "latest" || clean === "metatron") return SCALES[1];
	return SCALES.find((s) => s.id === clean || s.tag === id || s.tag === `metatron:${clean}`) ?? SCALES[1];
}
function tanh(x) {
	if (x > 8) return 1;
	if (x < -8) return -1;
	const e = Math.exp(2 * x);
	return (e - 1) / (e + 1);
}
function softmax(logits, temp) {
	const t = Math.max(temp, 1e-4);
	let max = -Infinity;
	for (let i = 0; i < logits.length; i++) max = Math.max(max, logits[i] / t);
	const out = new Float32Array(logits.length);
	let sum = 0;
	for (let i = 0; i < logits.length; i++) {
		const v = Math.exp(logits[i] / t - max);
		out[i] = v;
		sum += v;
	}
	for (let i = 0; i < out.length; i++) out[i] /= sum || 1;
	return out;
}
function sample(probs, topK) {
	const k = Math.min(topK, probs.length);
	const keep = Array.from(probs.keys()).sort((a, b) => probs[b] - probs[a]).slice(0, k);
	let z = 0;
	for (const i of keep) z += probs[i];
	let r = Math.random() * z;
	for (const i of keep) {
		r -= probs[i];
		if (r <= 0) return i;
	}
	return keep[0] ?? 0;
}
var WORD_RE = /[a-z0-9']+|[^a-z0-9'\s]/gi;
function splitWords(text) {
	return (text.toLowerCase().match(WORD_RE) ?? []).filter((w) => w.trim().length);
}
var Tokenizer = class {
	itos;
	stoi;
	unk = 1;
	bos = 2;
	eos = 3;
	constructor(size, corpus) {
		const special = [
			"<pad>",
			"<unk>",
			"<bos>",
			"<eos>"
		];
		const freq = /* @__PURE__ */ new Map();
		for (const w of splitWords(corpus)) freq.set(w, (freq.get(w) ?? 0) + 1);
		const ranked = [...freq.entries()].sort((a, b) => b[1] - a[1]).map(([w]) => w);
		this.itos = [...special, ...ranked].slice(0, size);
		while (this.itos.length < size) this.itos.push(`<x${this.itos.length}>`);
		this.stoi = new Map(this.itos.map((c, i) => [c, i]));
	}
	encode(text, bos = true) {
		const ids = bos ? [this.bos] : [];
		for (const w of splitWords(text)) ids.push(this.stoi.get(w) ?? this.unk);
		return ids;
	}
	decode(ids) {
		const parts = [];
		for (const i of ids) {
			const t = this.itos[i];
			if (!t || t.startsWith("<")) continue;
			if (/^[^a-z0-9']$/i.test(t)) parts.push(t);
			else {
				if (parts.length) parts.push(" ");
				parts.push(t);
			}
		}
		return parts.join("").replace(/\s+([.,!?;:])/g, "$1").trim();
	}
	decodeOne(id) {
		const t = this.itos[id];
		if (!t || t.startsWith("<")) return "";
		if (/^[^a-z0-9']$/i.test(t)) return t;
		return t;
	}
};
function linear(inD, outD) {
	const w = new Float32Array(outD * inD);
	const s = Math.sqrt(2 / inD);
	for (let i = 0; i < w.length; i++) w[i] = (Math.random() * 2 - 1) * s;
	return {
		w,
		b: new Float32Array(outD),
		in: inD,
		out: outD
	};
}
function linForward(l, x) {
	const y = new Float32Array(l.out);
	for (let o = 0; o < l.out; o++) {
		let s = l.b[o];
		const row = o * l.in;
		for (let i = 0; i < l.in; i++) s += l.w[row + i] * x[i];
		y[o] = s;
	}
	return y;
}
function linStep(l, x, dy, lr) {
	const dx = new Float32Array(l.in);
	let n2 = 0;
	for (let i = 0; i < dy.length; i++) n2 += dy[i] * dy[i];
	const sc = Math.min(1, 1 / (Math.sqrt(n2) + 1e-6));
	for (let o = 0; o < l.out; o++) {
		const g = dy[o] * sc;
		l.b[o] -= lr * g;
		const row = o * l.in;
		for (let i = 0; i < l.in; i++) {
			l.w[row + i] -= lr * g * x[i];
			dx[i] += l.w[row + i] * g;
		}
	}
	return dx;
}
function topology(n) {
	return Array.from({ length: n }, (_, i) => [
		(i + 1) % n,
		(i - 1 + n) % n,
		(i + 3) % n,
		(i + 7) % n
	]);
}
function trainTrigram(ids) {
	const map = /* @__PURE__ */ new Map();
	for (let i = 2; i < ids.length; i++) {
		const key = `${ids[i - 2]},${ids[i - 1]}`;
		let inner = map.get(key);
		if (!inner) {
			inner = /* @__PURE__ */ new Map();
			map.set(key, inner);
		}
		inner.set(ids[i], (inner.get(ids[i]) ?? 0) + 1);
	}
	return { map };
}
function trigramProbs(tg, a, b, vocab) {
	const p = new Float32Array(vocab);
	const inner = tg.map.get(`${a},${b}`) ?? tg.map.get(`-1,${b}`);
	if (!inner) {
		for (let i = 4; i < Math.min(vocab, 80); i++) p[i] = 1;
		let s = 0;
		for (let i = 0; i < vocab; i++) s += p[i];
		for (let i = 0; i < vocab; i++) p[i] /= s || 1;
		return p;
	}
	let s = 0;
	for (const [k, v] of inner) if (k < vocab) {
		p[k] = v;
		s += v;
	}
	for (let i = 0; i < vocab; i++) p[i] = (p[i] + .08) / (s + .08 * vocab);
	return p;
}
function tryMath(prompt) {
	const m = prompt.replace(/,/g, "").match(/(-?\d+(?:\.\d+)?)\s*([+\-*/x×÷])\s*(-?\d+(?:\.\d+)?)/);
	if (!m) return null;
	const a = Number(m[1]);
	const b = Number(m[3]);
	const op = m[2];
	let r;
	if (op === "+") r = a + b;
	else if (op === "-") r = a - b;
	else if (op === "*" || op === "x" || op === "×") r = a * b;
	else {
		if (b === 0) return "Division by zero. Hands refuse.";
		r = a / b;
	}
	return `${a} ${op} ${b} = ${Number.isInteger(r) ? String(r) : r.toFixed(4).replace(/0+$/, "").replace(/\.$/, "")}`;
}
function retrieve(prompt, n) {
	const words = new Set(splitWords(prompt).filter((w) => w.length > 2));
	if (!words.size) return [];
	return SENTENCES.map((s) => {
		const sw = splitWords(s);
		let hit = 0;
		for (const w of sw) if (words.has(w)) hit++;
		return {
			s,
			hit
		};
	}).filter((x) => x.hit > 0).sort((a, b) => b.hit - a.hit).slice(0, n).map((x) => {
		const t = x.s.trim();
		return t.endsWith(".") ? t : `${t}.`;
	});
}
var MetatronEngine = class {
	scale;
	tok;
	embed;
	mixer;
	gates;
	recs;
	head;
	topo;
	trigram;
	memory = [];
	loaded = false;
	created = true;
	trainedEpochs = 0;
	lastLoss = 0;
	lastOrgans = ORGANS.map((o) => ({
		id: o.id,
		activation: .08
	}));
	alias;
	constructor(scale) {
		this.scale = scale;
		this.tok = new Tokenizer(scale.vocab, CORPUS);
		const { dim, modules, vocab } = scale;
		this.embed = new Float32Array(vocab * dim);
		const s = Math.sqrt(2 / dim);
		for (let i = 0; i < this.embed.length; i++) this.embed[i] = (Math.random() * 2 - 1) * s;
		this.mixer = linear(dim, dim);
		this.head = linear(dim, vocab);
		this.gates = Array.from({ length: modules }, () => linear(dim, dim));
		this.recs = Array.from({ length: modules }, () => linear(dim, dim));
		this.topo = topology(modules);
		this.trigram = trainTrigram(this.tok.encode(CORPUS, true));
	}
	embedTok(id) {
		const { dim } = this.scale;
		const out = new Float32Array(dim);
		const row = id % this.scale.vocab * dim;
		for (let i = 0; i < dim; i++) out[i] = this.embed[row + i];
		return out;
	}
	hidden(ids) {
		const { dim, modules, ctx } = this.scale;
		let h = new Float32Array(dim);
		const use = ids.slice(-ctx);
		let states = Array.from({ length: modules }, () => new Float32Array(dim));
		for (const id of use) {
			const x = this.embedTok(id);
			const mixed = linForward(this.mixer, x);
			const next = [];
			for (let m = 0; m < modules; m++) {
				const rec = linForward(this.recs[m], mixed);
				const st = new Float32Array(dim);
				const neigh = this.topo[m];
				for (let i = 0; i < dim; i++) {
					let msg = 0;
					for (const n of neigh) msg += states[n][i];
					msg /= neigh.length;
					st[i] = tanh(.65 * rec[i] + .35 * mixed[i] + .25 * msg + .15 * h[i]);
				}
				const g = linForward(this.gates[m], st);
				for (let i = 0; i < dim; i++) st[i] = st[i] * (1 / (1 + Math.exp(-Math.max(-12, Math.min(12, g[i])))));
				next.push(st);
			}
			states = next;
			h = new Float32Array(dim);
			for (let i = 0; i < dim; i++) {
				let s = 0;
				for (let m = 0; m < modules; m++) s += states[m][i];
				h[i] = s / modules;
			}
		}
		return {
			h,
			states
		};
	}
	organPulse(h) {
		const dim = this.scale.dim;
		return ORGANS.map((o, i) => {
			let a = 0;
			const start = i * 3 % dim;
			for (let k = 0; k < 4; k++) a += Math.abs(h[(start + k) % dim]);
			return {
				id: o.id,
				activation: Math.min(1, a / 2.2)
			};
		});
	}
	logits(h) {
		return linForward(this.head, h);
	}
	trainEpochs(epochs, onEpoch) {
		const ids = this.tok.encode(CORPUS, true);
		const logs = [];
		const ctx = this.scale.ctx;
		for (let e = 0; e < epochs; e++) {
			const t0 = performance.now();
			let loss = 0;
			let n = 0;
			const step = Math.max(4, Math.floor(ctx / 2));
			const cap = 36;
			for (let i = 0; i + 6 < ids.length && n < cap; i += step) {
				const seq = ids.slice(i, i + ctx + 1);
				if (seq.length < 4) continue;
				const inputs = seq.slice(0, -1);
				const targets = seq.slice(1);
				const { h } = this.hidden(inputs);
				const logit = this.logits(h);
				const p = softmax(logit, 1);
				const tgt = targets[targets.length - 1];
				loss += -Math.log(p[tgt] + 1e-8);
				n++;
				const dy = new Float32Array(logit.length);
				for (let v = 0; v < dy.length; v++) dy[v] = p[v];
				dy[tgt] -= 1;
				const dh = linStep(this.head, h, dy, this.scale.lr);
				linStep(this.mixer, this.embedTok(inputs[inputs.length - 1]), dh, this.scale.lr * .5);
				const row = tgt * this.scale.dim;
				for (let d = 0; d < this.scale.dim; d++) this.embed[row + d] -= this.scale.lr * .05 * dh[d];
			}
			const avg = loss / Math.max(1, n);
			const log = {
				epoch: this.trainedEpochs + 1,
				loss: avg,
				ppl: Math.exp(Math.min(avg, 12)),
				ms: performance.now() - t0
			};
			this.trainedEpochs += 1;
			this.lastLoss = avg;
			logs.push(log);
			onEpoch?.(log);
		}
		this.loaded = true;
		return logs;
	}
	remember(key, value) {
		this.memory.unshift({
			key,
			value
		});
		if (this.memory.length > 64) this.memory.pop();
	}
	matchKnowledge(prompt) {
		const q = ` ${prompt.toLowerCase()} `;
		for (const row of KNOWLEDGE) if (row.keys.some((k) => q.includes(k))) return {
			organ: row.organ,
			answer: row.answer
		};
		return null;
	}
	compose(prompt) {
		const known = this.matchKnowledge(prompt);
		if (known) return {
			text: known.answer,
			organ: known.organ,
			canned: true
		};
		const math = tryMath(prompt);
		if (math) return {
			text: math,
			organ: "hands",
			canned: true
		};
		const q = prompt.trim();
		if (!(/[?]$/.test(q) || /^(who|what|how|why|where|when|can|do|does|is|are|should|could|explain|tell)\b/i.test(q)) && splitWords(q).length >= 3) {
			const cont = this.ngramContinue(q, 28);
			if (splitWords(cont).length >= 6) return {
				text: cont,
				organ: "mouth",
				canned: false
			};
		}
		const related = retrieve(q, 2);
		if (related.length) return {
			text: related.join(" "),
			organ: "memory",
			canned: true
		};
		return {
			text: "Loaded, but that is not in my corpus. Ask about the Flower of Life, the organs, training, or how to call this Ollama API.",
			organ: "heart",
			canned: true
		};
	}
	ngramContinue(prompt, maxNew) {
		let ids = this.tok.encode(prompt.slice(-240), true);
		for (let t = 0; t < maxNew; t++) {
			const { h } = this.hidden(ids);
			this.lastOrgans = this.organPulse(h);
			const neural = softmax(this.logits(h), .8);
			const a = ids[ids.length - 2] ?? this.tok.bos;
			const b = ids[ids.length - 1] ?? this.tok.bos;
			const tg = trigramProbs(this.trigram, a, b, this.scale.vocab);
			const mix = new Float32Array(this.scale.vocab);
			for (let i = 0; i < mix.length; i++) mix[i] = .22 * neural[i] + .78 * tg[i];
			const next = sample(mix, 12);
			if (next === this.tok.eos) break;
			ids.push(next);
			if (ids.length > this.scale.ctx + 4) ids = ids.slice(-this.scale.ctx);
			if (!this.tok.decodeOne(next)) continue;
			const soFar = this.tok.decode(ids.slice(1));
			if (soFar.length > prompt.length + 8 && /[.!?]$/.test(soFar) && t > 8) break;
		}
		const decoded = this.tok.decode(ids.slice(1));
		const lower = decoded.toLowerCase();
		const p = prompt.toLowerCase().trim();
		if (lower.startsWith(p) && decoded.length > p.length + 4) return decoded.slice(p.length).replace(/^[\s,;:]+/, "").replace(/^./, (c) => c.toLowerCase());
		return decoded;
	}
	generate(opts) {
		const prompt = opts.prompt ?? "";
		const { text, organ, canned } = this.compose(prompt);
		const ids = this.tok.encode(prompt.slice(-this.scale.ctx) || text.slice(0, 80), true);
		const { h } = this.hidden(ids);
		this.lastOrgans = this.organPulse(h);
		this.lastOrgans = ORGANS.map((o) => ({
			id: o.id,
			activation: o.id === organ ? .94 : .16 + Math.random() * .18
		}));
		const words = canned ? splitForStream(text) : splitForStream(text);
		let acc = "";
		for (const w of words) {
			acc += w;
			opts.onToken?.(w, this.lastOrgans);
		}
		return text;
	}
	chat(messages, opts = {}) {
		const lastUser = [...messages].reverse().find((m) => m.role === "user")?.content ?? "";
		const lastAsst = [...messages].reverse().find((m) => m.role === "assistant")?.content;
		if (lastUser) this.remember("user", lastUser.slice(0, 240));
		if (lastAsst) this.remember("assistant", lastAsst.slice(0, 240));
		return this.generate({
			...opts,
			prompt: lastUser
		});
	}
	embedText(text, dim = 64) {
		const ids = this.tok.encode(text, false);
		const out = new Array(dim).fill(0);
		for (let i = 0; i < ids.length; i++) {
			const v = ids[i];
			out[v % dim] += 1;
			out[v * 7 % dim] += .5;
		}
		const n = Math.sqrt(out.reduce((s, x) => s + x * x, 0)) || 1;
		return out.map((x) => x / n);
	}
};
function splitForStream(text) {
	const parts = text.split(/(\s+)/);
	const out = [];
	for (const p of parts) if (p) out.push(p);
	return out.length ? out : [text];
}
function cloneEngine(src, tag) {
	const eng = new MetatronEngine(src.scale);
	eng.embed = new Float32Array(src.embed);
	eng.loaded = src.loaded;
	eng.trainedEpochs = src.trainedEpochs;
	eng.lastLoss = src.lastLoss;
	eng.trigram = src.trigram;
	eng.alias = tag;
	return eng;
}
var runtime_exports = /* @__PURE__ */ __exportAll({
	copyModel: () => copyModel,
	createFromModelfile: () => createFromModelfile,
	deleteModel: () => deleteModel,
	ensureLoaded: () => ensureLoaded,
	getEngine: () => getEngine,
	listLibrary: () => listLibrary,
	listLoaded: () => listLoaded,
	pullModel: () => pullModel,
	resolveId: () => resolveId,
	sleep: () => sleep,
	trainMore: () => trainMore
});
function bag() {
	const g = globalThis;
	if (!g.__metatronEngines) g.__metatronEngines = /* @__PURE__ */ new Map();
	return g.__metatronEngines;
}
function aliases() {
	const g = globalThis;
	if (!g.__metatronAliases) g.__metatronAliases = /* @__PURE__ */ new Map([
		["metatron", "ultra"],
		["metatron:latest", "ultra"],
		["latest", "ultra"]
	]);
	return g.__metatronAliases;
}
function seedLibrary() {
	const m = bag();
	if (m.size) return;
	for (const s of SCALES) if (!m.has(s.id)) m.set(s.id, new MetatronEngine(s));
}
function resolveId(name) {
	const raw = name.replace(/^ollama\//, "").trim();
	const mapped = aliases().get(raw) ?? aliases().get(raw.toLowerCase());
	if (mapped === "nano" || mapped === "ultra" || mapped === "tiny") return mapped;
	return getScale(raw).id;
}
function getEngine(name = "metatron:ultra") {
	seedLibrary();
	const id = resolveId(name);
	const m = bag();
	let eng = m.get(id);
	if (!eng) {
		eng = new MetatronEngine(getScale(id));
		m.set(id, eng);
	}
	return eng;
}
function listLibrary() {
	seedLibrary();
	return [...bag().values()];
}
function listLoaded() {
	return listLibrary().filter((e) => e.loaded);
}
function copyModel(source, destination) {
	const src = getEngine(source);
	const dest = destination.replace(/^ollama\//, "").trim();
	const clone = cloneEngine(src, dest);
	bag().set(dest, clone);
	aliases().set(dest, src.scale.id);
	return clone;
}
function deleteModel(name) {
	const key = name.replace(/^ollama\//, "").trim();
	const m = bag();
	if (m.has(key)) {
		m.delete(key);
		aliases().delete(key);
		return true;
	}
	const id = resolveId(name);
	if (SCALES.some((s) => s.id === id)) {
		const eng = m.get(id);
		if (eng) {
			eng.loaded = false;
			eng.trainedEpochs = 0;
		}
		return true;
	}
	return m.delete(id);
}
function ensureLoaded(name) {
	const eng = getEngine(name);
	if (!eng.loaded) {
		const warm = eng.scale.id === "nano" ? 2 : eng.scale.id === "ultra" ? 3 : 4;
		eng.trainEpochs(warm);
	}
	return eng;
}
function sleep(ms) {
	return new Promise((r) => setTimeout(r, ms));
}
async function pullModel(name, onEvent) {
	const eng = getEngine(name);
	const s = eng.scale;
	const total = s.params * 4;
	onEvent({ status: "pulling manifest" });
	await sleep(60);
	if (eng.loaded) {
		onEvent({
			status: "pulling " + s.digest,
			digest: `sha256:${s.digest}${"0".repeat(48)}`.slice(0, 71),
			total,
			completed: total
		});
		await sleep(40);
		onEvent({ status: "verifying sha256 digest" });
		await sleep(40);
		onEvent({ status: "success" });
		return eng;
	}
	const digest = `sha256:${s.digest}${"0".repeat(48)}`.slice(0, 71);
	onEvent({
		status: `pulling ${digest}`,
		digest,
		total,
		completed: 0
	});
	await sleep(50);
	onEvent({ status: `pulling flower-of-life topology (${s.modules} modules)` });
	await sleep(70);
	onEvent({ status: "pulling organ seeds: brain memory ears mouth hands heart legs" });
	await sleep(60);
	const warm = s.id === "nano" ? 2 : s.id === "ultra" ? 3 : 4;
	for (let i = 0; i < warm; i++) {
		const [log] = eng.trainEpochs(1);
		const completed = Math.round((i + 1) / warm * total);
		onEvent({
			status: `pulling ${digest}`,
			digest,
			total,
			completed
		});
		if (log) onEvent({ status: `warming weights  epoch ${log.epoch}  loss ${log.loss.toFixed(3)}  ppl ${log.ppl.toFixed(1)}` });
		await sleep(16);
	}
	onEvent({ status: "verifying sha256 digest" });
	await sleep(50);
	onEvent({ status: "writing manifest" });
	await sleep(40);
	onEvent({ status: "success" });
	eng.loaded = true;
	return eng;
}
function createFromModelfile(model, modelfile) {
	const from = /FROM\s+(\S+)/i.exec(modelfile)?.[1] ?? "metatron:ultra";
	const tag = model.replace(/^ollama\//, "").trim() || `metatron:custom`;
	const src = ensureLoaded(from);
	const clone = cloneEngine(src, tag);
	bag().set(tag, clone);
	aliases().set(tag, src.scale.id);
	return {
		scale: src.scale,
		tag
	};
}
function trainMore(name, epochs) {
	return getEngine(name).trainEpochs(Math.max(1, Math.min(32, epochs)));
}
//#endregion
export { listLibrary as a, runtime_exports as c, SCALES as d, getScale as f, getEngine as i, sleep as l, __exportAll as m, createFromModelfile as n, listLoaded as o, ORGANS as p, deleteModel as r, pullModel as s, copyModel as t, trainMore as u };
