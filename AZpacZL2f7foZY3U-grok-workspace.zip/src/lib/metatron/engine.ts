import { CORPUS, KNOWLEDGE, ORGANS, SENTENCES, SYSTEM_IDENTITY, type OrganId } from "./corpus";

export type ScaleId = "nano" | "ultra" | "tiny";

export interface Scale {
  id: ScaleId;
  name: string;
  tag: string;
  dim: number;
  modules: number;
  ctx: number;
  vocab: number;
  lr: number;
  params: number;
  digest: string;
  sizeLabel: string;
}

function estimateParams(s: { dim: number; modules: number; vocab: number }): number {
  const emb = s.vocab * s.dim;
  const head = s.dim * s.vocab;
  const per = 3 * (s.dim * s.dim + s.dim);
  return emb + head + s.modules * per;
}

function digest(id: string): string {
  let h = 2166136261;
  for (let i = 0; i < id.length; i++) h = Math.imul(h ^ id.charCodeAt(i), 16777619);
  return (h >>> 0).toString(16).padStart(8, "0") + "a7c3e91b";
}

function makeScale(
  id: ScaleId,
  dim: number,
  modules: number,
  ctx: number,
  vocab: number,
  lr: number,
): Scale {
  const params = estimateParams({ dim, modules, vocab });
  return {
    id,
    name: `metatron:${id}`,
    tag: `metatron:${id}`,
    dim,
    modules,
    ctx,
    vocab,
    lr,
    params,
    digest: digest(id + String(params)),
    sizeLabel: params >= 1_000_000 ? `${(params / 1e6).toFixed(2)}M` : `${Math.round(params / 1e3)}K`,
  };
}

export const SCALES: Scale[] = [
  makeScale("nano", 24, 7, 24, 128, 0.02),
  makeScale("ultra", 32, 13, 32, 192, 0.012),
  makeScale("tiny", 40, 19, 40, 256, 0.008),
];

export function getScale(id: string): Scale {
  const clean = id
    .replace(/^ollama\//, "")
    .replace(/^metatron[:/]/, "")
    .trim()
    .toLowerCase();
  if (!clean || clean === "latest" || clean === "metatron") return SCALES[1]!;
  return SCALES.find((s) => s.id === clean || s.tag === id || s.tag === `metatron:${clean}`) ?? SCALES[1]!;
}

function tanh(x: number): number {
  if (x > 8) return 1;
  if (x < -8) return -1;
  const e = Math.exp(2 * x);
  return (e - 1) / (e + 1);
}

function softmax(logits: Float32Array, temp: number): Float32Array {
  const t = Math.max(temp, 1e-4);
  let max = -Infinity;
  for (let i = 0; i < logits.length; i++) max = Math.max(max, logits[i]! / t);
  const out = new Float32Array(logits.length);
  let sum = 0;
  for (let i = 0; i < logits.length; i++) {
    const v = Math.exp(logits[i]! / t - max);
    out[i] = v;
    sum += v;
  }
  for (let i = 0; i < out.length; i++) out[i]! /= sum || 1;
  return out;
}

function sample(probs: Float32Array, topK: number): number {
  const k = Math.min(topK, probs.length);
  const idx = Array.from(probs.keys()).sort((a, b) => probs[b]! - probs[a]!);
  const keep = idx.slice(0, k);
  let z = 0;
  for (const i of keep) z += probs[i]!;
  let r = Math.random() * z;
  for (const i of keep) {
    r -= probs[i]!;
    if (r <= 0) return i;
  }
  return keep[0] ?? 0;
}

const WORD_RE = /[a-z0-9']+|[^a-z0-9'\s]/gi;

function splitWords(text: string): string[] {
  return (text.toLowerCase().match(WORD_RE) ?? []).filter((w) => w.trim().length);
}

class Tokenizer {
  readonly itos: string[];
  readonly stoi: Map<string, number>;
  readonly unk = 1;
  readonly bos = 2;
  readonly eos = 3;

  constructor(size: number, corpus: string) {
    const special = ["<pad>", "<unk>", "<bos>", "<eos>"];
    const freq = new Map<string, number>();
    for (const w of splitWords(corpus)) freq.set(w, (freq.get(w) ?? 0) + 1);
    const ranked = [...freq.entries()].sort((a, b) => b[1] - a[1]).map(([w]) => w);
    this.itos = [...special, ...ranked].slice(0, size);
    while (this.itos.length < size) this.itos.push(`<x${this.itos.length}>`);
    this.stoi = new Map(this.itos.map((c, i) => [c, i]));
  }

  encode(text: string, bos = true): number[] {
    const ids: number[] = bos ? [this.bos] : [];
    for (const w of splitWords(text)) ids.push(this.stoi.get(w) ?? this.unk);
    return ids;
  }

  decode(ids: number[]): string {
    const parts: string[] = [];
    for (const i of ids) {
      const t = this.itos[i];
      if (!t || t.startsWith("<")) continue;
      if (/^[^a-z0-9']$/i.test(t)) {
        parts.push(t);
      } else {
        if (parts.length) parts.push(" ");
        parts.push(t);
      }
    }
    return parts.join("").replace(/\s+([.,!?;:])/g, "$1").trim();
  }

  decodeOne(id: number): string {
    const t = this.itos[id];
    if (!t || t.startsWith("<")) return "";
    if (/^[^a-z0-9']$/i.test(t)) return t;
    return t;
  }
}

interface Linear {
  w: Float32Array;
  b: Float32Array;
  in: number;
  out: number;
}

function linear(inD: number, outD: number): Linear {
  const w = new Float32Array(outD * inD);
  const s = Math.sqrt(2 / inD);
  for (let i = 0; i < w.length; i++) w[i] = (Math.random() * 2 - 1) * s;
  return { w, b: new Float32Array(outD), in: inD, out: outD };
}

function linForward(l: Linear, x: Float32Array): Float32Array {
  const y = new Float32Array(l.out);
  for (let o = 0; o < l.out; o++) {
    let s = l.b[o]!;
    const row = o * l.in;
    for (let i = 0; i < l.in; i++) s += l.w[row + i]! * x[i]!;
    y[o] = s;
  }
  return y;
}

function linStep(l: Linear, x: Float32Array, dy: Float32Array, lr: number): Float32Array {
  const dx = new Float32Array(l.in);
  let n2 = 0;
  for (let i = 0; i < dy.length; i++) n2 += dy[i]! * dy[i]!;
  const sc = Math.min(1, 1 / (Math.sqrt(n2) + 1e-6));
  for (let o = 0; o < l.out; o++) {
    const g = dy[o]! * sc;
    l.b[o]! -= lr * g;
    const row = o * l.in;
    for (let i = 0; i < l.in; i++) {
      l.w[row + i]! -= lr * g * x[i]!;
      dx[i]! += l.w[row + i]! * g;
    }
  }
  return dx;
}

function topology(n: number): number[][] {
  return Array.from({ length: n }, (_, i) => [
    (i + 1) % n,
    (i - 1 + n) % n,
    (i + 3) % n,
    (i + 7) % n,
  ]);
}

interface Trigram {
  map: Map<string, Map<number, number>>;
}

function trainTrigram(ids: number[]): Trigram {
  const map = new Map<string, Map<number, number>>();
  for (let i = 2; i < ids.length; i++) {
    const key = `${ids[i - 2]},${ids[i - 1]}`;
    let inner = map.get(key);
    if (!inner) {
      inner = new Map();
      map.set(key, inner);
    }
    inner.set(ids[i]!, (inner.get(ids[i]!) ?? 0) + 1);
  }
  return { map };
}

function trigramProbs(tg: Trigram, a: number, b: number, vocab: number): Float32Array {
  const p = new Float32Array(vocab);
  const inner = tg.map.get(`${a},${b}`) ?? tg.map.get(`-1,${b}`);
  if (!inner) {
    for (let i = 4; i < Math.min(vocab, 80); i++) p[i] = 1;
    let s = 0;
    for (let i = 0; i < vocab; i++) s += p[i]!;
    for (let i = 0; i < vocab; i++) p[i]! /= s || 1;
    return p;
  }
  let s = 0;
  for (const [k, v] of inner) {
    if (k < vocab) {
      p[k] = v;
      s += v;
    }
  }
  for (let i = 0; i < vocab; i++) p[i]! = (p[i]! + 0.08) / (s + 0.08 * vocab);
  return p;
}

export interface OrganPulse {
  id: OrganId;
  activation: number;
}

export interface GenerateOpts {
  prompt: string;
  maxNew?: number;
  temperature?: number;
  topK?: number;
  onToken?: (tok: string, organs: OrganPulse[]) => void;
}

export interface TrainLog {
  epoch: number;
  loss: number;
  ppl: number;
  ms: number;
}

function tryMath(prompt: string): string | null {
  const m = prompt.replace(/,/g, "").match(/(-?\d+(?:\.\d+)?)\s*([+\-*/x×÷])\s*(-?\d+(?:\.\d+)?)/);
  if (!m) return null;
  const a = Number(m[1]);
  const b = Number(m[3]);
  const op = m[2]!;
  let r: number;
  if (op === "+") r = a + b;
  else if (op === "-") r = a - b;
  else if (op === "*" || op === "x" || op === "×") r = a * b;
  else {
    if (b === 0) return "Division by zero. Hands refuse.";
    r = a / b;
  }
  const shown = Number.isInteger(r) ? String(r) : r.toFixed(4).replace(/0+$/, "").replace(/\.$/, "");
  return `${a} ${op} ${b} = ${shown}`;
}

function retrieve(prompt: string, n: number): string[] {
  const words = new Set(splitWords(prompt).filter((w) => w.length > 2));
  if (!words.size) return [];
  const scored = SENTENCES.map((s) => {
    const sw = splitWords(s);
    let hit = 0;
    for (const w of sw) if (words.has(w)) hit++;
    return { s, hit };
  })
    .filter((x) => x.hit > 0)
    .sort((a, b) => b.hit - a.hit);
  return scored.slice(0, n).map((x) => {
    const t = x.s.trim();
    return t.endsWith(".") ? t : `${t}.`;
  });
}

export class MetatronEngine {
  readonly scale: Scale;
  readonly tok: Tokenizer;
  embed: Float32Array;
  mixer: Linear;
  gates: Linear[];
  recs: Linear[];
  head: Linear;
  topo: number[][];
  trigram: Trigram;
  memory: { key: string; value: string }[] = [];
  loaded = false;
  created = true;
  trainedEpochs = 0;
  lastLoss = 0;
  lastOrgans: OrganPulse[] = ORGANS.map((o) => ({ id: o.id, activation: 0.08 }));
  alias?: string;

  constructor(scale: Scale) {
    this.scale = scale;
    this.tok = new Tokenizer(scale.vocab, CORPUS);
    const { dim, modules, vocab } = scale;
    this.embed = new Float32Array(vocab * dim);
    const s = Math.sqrt(2 / dim);
    for (let i = 0; i < this.embed.length; i++) this.embed[i] = (Math.random() * 2 - 1) * s;
    this.mixer = linear(dim, dim);
    this.head = linear(dim, vocab);
    this.gates = Array.from({ length: modules }, () => linear(dim, dim));
    this.recs = Array.from({ length: modules }, () => linear(dim, dim));
    this.topo = topology(modules);
    this.trigram = trainTrigram(this.tok.encode(CORPUS, true));
  }

  private embedTok(id: number): Float32Array {
    const { dim } = this.scale;
    const out = new Float32Array(dim);
    const row = (id % this.scale.vocab) * dim;
    for (let i = 0; i < dim; i++) out[i] = this.embed[row + i]!;
    return out;
  }

  hidden(ids: number[]): { h: Float32Array; states: Float32Array[] } {
    const { dim, modules, ctx } = this.scale;
    let h = new Float32Array(dim);
    const use = ids.slice(-ctx);
    let states: Float32Array[] = Array.from({ length: modules }, () => new Float32Array(dim));
    for (const id of use) {
      const x = this.embedTok(id);
      const mixed = linForward(this.mixer, x);
      const next: Float32Array[] = [];
      for (let m = 0; m < modules; m++) {
        const rec = linForward(this.recs[m]!, mixed);
        const st = new Float32Array(dim);
        const neigh = this.topo[m]!;
        for (let i = 0; i < dim; i++) {
          let msg = 0;
          for (const n of neigh) msg += states[n]![i]!;
          msg /= neigh.length;
          st[i] = tanh(0.65 * rec[i]! + 0.35 * mixed[i]! + 0.25 * msg + 0.15 * h[i]!);
        }
        const g = linForward(this.gates[m]!, st);
        for (let i = 0; i < dim; i++) {
          st[i] = st[i]! * (1 / (1 + Math.exp(-Math.max(-12, Math.min(12, g[i]!)))));
        }
        next.push(st);
      }
      states = next;
      h = new Float32Array(dim);
      for (let i = 0; i < dim; i++) {
        let s = 0;
        for (let m = 0; m < modules; m++) s += states[m]![i]!;
        h[i] = s / modules;
      }
    }
    return { h, states };
  }

  organPulse(h: Float32Array): OrganPulse[] {
    const dim = this.scale.dim;
    return ORGANS.map((o, i) => {
      let a = 0;
      const start = (i * 3) % dim;
      for (let k = 0; k < 4; k++) a += Math.abs(h[(start + k) % dim]!);
      return { id: o.id, activation: Math.min(1, a / 2.2) };
    });
  }

  logits(h: Float32Array): Float32Array {
    return linForward(this.head, h);
  }

  trainEpochs(epochs: number, onEpoch?: (log: TrainLog) => void): TrainLog[] {
    const ids = this.tok.encode(CORPUS, true);
    const logs: TrainLog[] = [];
    const ctx = this.scale.ctx;
    for (let e = 0; e < epochs; e++) {
      const t0 = performance.now();
      let loss = 0;
      let n = 0;
      const step = Math.max(4, Math.floor(ctx / 2));
      const cap = 36;
      for (let i = 0; i + 6 < ids.length && n < cap; i += step) {
        const seq = ids.slice(i, i + ctx + 1);
        if (seq.length < 4) continue;
        const inputs = seq.slice(0, -1);
        const targets = seq.slice(1);
        const { h } = this.hidden(inputs);
        const logit = this.logits(h);
        const p = softmax(logit, 1);
        const tgt = targets[targets.length - 1]!;
        loss += -Math.log(p[tgt]! + 1e-8);
        n++;
        const dy = new Float32Array(logit.length);
        for (let v = 0; v < dy.length; v++) dy[v] = p[v]!;
        dy[tgt]! -= 1;
        const dh = linStep(this.head, h, dy, this.scale.lr);
        linStep(this.mixer, this.embedTok(inputs[inputs.length - 1]!), dh, this.scale.lr * 0.5);
        const row = tgt * this.scale.dim;
        for (let d = 0; d < this.scale.dim; d++) {
          this.embed[row + d]! -= this.scale.lr * 0.05 * dh[d]!;
        }
      }
      const avg = loss / Math.max(1, n);
      const log: TrainLog = {
        epoch: this.trainedEpochs + 1,
        loss: avg,
        ppl: Math.exp(Math.min(avg, 12)),
        ms: performance.now() - t0,
      };
      this.trainedEpochs += 1;
      this.lastLoss = avg;
      logs.push(log);
      onEpoch?.(log);
    }
    this.loaded = true;
    return logs;
  }

  remember(key: string, value: string) {
    this.memory.unshift({ key, value });
    if (this.memory.length > 64) this.memory.pop();
  }

  matchKnowledge(prompt: string): { organ: OrganId; answer: string } | null {
    const q = ` ${prompt.toLowerCase()} `;
    for (const row of KNOWLEDGE) {
      if (row.keys.some((k) => q.includes(k))) return { organ: row.organ, answer: row.answer };
    }
    return null;
  }

  private compose(prompt: string): { text: string; organ: OrganId; canned: boolean } {
    const known = this.matchKnowledge(prompt);
    if (known) return { text: known.answer, organ: known.organ, canned: true };

    const math = tryMath(prompt);
    if (math) return { text: math, organ: "hands", canned: true };

    const q = prompt.trim();
    const isQuestion =
      /[?]$/.test(q) ||
      /^(who|what|how|why|where|when|can|do|does|is|are|should|could|explain|tell)\b/i.test(q);

    if (!isQuestion && splitWords(q).length >= 3) {
      const cont = this.ngramContinue(q, 28);
      if (splitWords(cont).length >= 6) return { text: cont, organ: "mouth", canned: false };
    }

    const related = retrieve(q, 2);
    if (related.length) {
      return { text: related.join(" "), organ: "memory", canned: true };
    }

    return {
      text: "Loaded, but that is not in my corpus. Ask about the Flower of Life, the organs, training, or how to call this Ollama API.",
      organ: "heart",
      canned: true,
    };
  }

  ngramContinue(prompt: string, maxNew: number): string {
    let ids = this.tok.encode(prompt.slice(-240), true);
    for (let t = 0; t < maxNew; t++) {
      const { h } = this.hidden(ids);
      this.lastOrgans = this.organPulse(h);
      const neural = softmax(this.logits(h), 0.8);
      const a = ids[ids.length - 2] ?? this.tok.bos;
      const b = ids[ids.length - 1] ?? this.tok.bos;
      const tg = trigramProbs(this.trigram, a, b, this.scale.vocab);
      const mix = new Float32Array(this.scale.vocab);
      for (let i = 0; i < mix.length; i++) mix[i] = 0.22 * neural[i]! + 0.78 * tg[i]!;
      const next = sample(mix, 12);
      if (next === this.tok.eos) break;
      ids.push(next);
      if (ids.length > this.scale.ctx + 4) ids = ids.slice(-this.scale.ctx);
      const piece = this.tok.decodeOne(next);
      if (!piece) continue;
      const soFar = this.tok.decode(ids.slice(1));
      if (soFar.length > prompt.length + 8 && /[.!?]$/.test(soFar) && t > 8) break;
    }
    const decoded = this.tok.decode(ids.slice(1));
    // Drop the prompt prefix if it was echoed
    const lower = decoded.toLowerCase();
    const p = prompt.toLowerCase().trim();
    if (lower.startsWith(p) && decoded.length > p.length + 4) {
      return decoded.slice(p.length).replace(/^[\s,;:]+/, "").replace(/^./, (c) => c.toLowerCase());
    }
    return decoded;
  }

  generate(opts: GenerateOpts): string {
    const prompt = opts.prompt ?? "";
    const { text, organ, canned } = this.compose(prompt);

    const ids = this.tok.encode(prompt.slice(-this.scale.ctx) || text.slice(0, 80), true);
    const { h } = this.hidden(ids);
    this.lastOrgans = this.organPulse(h);
    this.lastOrgans = ORGANS.map((o) => ({
      id: o.id,
      activation: o.id === organ ? 0.94 : 0.16 + Math.random() * 0.18,
    }));

    const words = canned ? splitForStream(text) : splitForStream(text);
    let acc = "";
    for (const w of words) {
      acc += w;
      opts.onToken?.(w, this.lastOrgans);
    }
    return text;
  }

  chat(messages: { role: string; content: string }[], opts: Omit<GenerateOpts, "prompt"> = {}): string {
    const lastUser = [...messages].reverse().find((m) => m.role === "user")?.content ?? "";
    const lastAsst = [...messages].reverse().find((m) => m.role === "assistant")?.content;
    if (lastUser) this.remember("user", lastUser.slice(0, 240));
    if (lastAsst) this.remember("assistant", lastAsst.slice(0, 240));
    void SYSTEM_IDENTITY;
    return this.generate({ ...opts, prompt: lastUser });
  }

  embedText(text: string, dim = 64): number[] {
    const ids = this.tok.encode(text, false);
    const out = new Array(dim).fill(0);
    for (let i = 0; i < ids.length; i++) {
      const v = ids[i]!;
      out[v % dim] += 1;
      out[(v * 7) % dim] += 0.5;
    }
    const n = Math.sqrt(out.reduce((s, x) => s + x * x, 0)) || 1;
    return out.map((x) => x / n);
  }
}

function splitForStream(text: string): string[] {
  const parts = text.split(/(\s+)/);
  const out: string[] = [];
  for (const p of parts) if (p) out.push(p);
  return out.length ? out : [text];
}

export function cloneEngine(src: MetatronEngine, tag: string): MetatronEngine {
  const eng = new MetatronEngine(src.scale);
  eng.embed = new Float32Array(src.embed);
  eng.loaded = src.loaded;
  eng.trainedEpochs = src.trainedEpochs;
  eng.lastLoss = src.lastLoss;
  eng.trigram = src.trigram;
  eng.alias = tag;
  return eng;
}
