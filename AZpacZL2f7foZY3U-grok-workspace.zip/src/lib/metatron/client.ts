import type { OrganPulse, ScaleId, TrainLog } from "./engine";

export async function readNdjson(
  res: Response,
  onLine: (obj: Record<string, unknown>) => void,
): Promise<void> {
  if (!res.body) {
    const text = await res.text();
    for (const line of text.split("\n")) {
      if (!line.trim()) continue;
      onLine(JSON.parse(line) as Record<string, unknown>);
    }
    return;
  }
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = "";
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    const lines = buf.split("\n");
    buf = lines.pop() ?? "";
    for (const line of lines) {
      if (!line.trim()) continue;
      onLine(JSON.parse(line) as Record<string, unknown>);
    }
  }
  if (buf.trim()) onLine(JSON.parse(buf) as Record<string, unknown>);
}

export interface TagModel {
  name: string;
  size: number;
  digest: string;
  details?: { parameter_size?: string };
}

export async function fetchTags(): Promise<TagModel[]> {
  const res = await fetch("/api/tags");
  if (!res.ok) throw new Error(`tags ${res.status}`);
  const data = (await res.json()) as { models: TagModel[] };
  return data.models ?? [];
}

export async function fetchPs(): Promise<TagModel[]> {
  const res = await fetch("/api/ps");
  if (!res.ok) throw new Error(`ps ${res.status}`);
  const data = (await res.json()) as { models: TagModel[] };
  return data.models ?? [];
}

export async function fetchVersion(): Promise<string> {
  const res = await fetch("/api/version");
  if (!res.ok) return "unknown";
  const data = (await res.json()) as { version?: string };
  return data.version ?? "unknown";
}

export async function pullModel(
  name: string,
  onLine: (line: string, raw: Record<string, unknown>) => void,
): Promise<void> {
  const res = await fetch("/api/pull", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, stream: true }),
  });
  if (!res.ok) throw new Error(`pull ${res.status}`);
  await readNdjson(res, (obj) => {
    const status = String(obj.status ?? "");
    const total = Number(obj.total ?? 0);
    const completed = Number(obj.completed ?? 0);
    if (total && (obj.completed != null)) {
      const pct = Math.min(100, Math.round((completed / total) * 100));
      onLine(`${status}  ${pct}%`, obj);
    } else {
      onLine(status, obj);
    }
  });
}

export async function chatStream(
  model: string,
  messages: { role: string; content: string }[],
  onTok: (tok: string, organs?: OrganPulse[]) => void,
): Promise<string> {
  const res = await fetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model, messages, stream: true }),
  });
  if (!res.ok) throw new Error(`chat ${res.status}`);
  let full = "";
  await readNdjson(res, (obj) => {
    const msg = obj.message as { content?: string } | undefined;
    const piece = msg?.content ?? "";
    const organs = obj.organs as OrganPulse[] | undefined;
    if (obj.done === true) {
      if (organs) onTok("", organs);
      return;
    }
    if (piece) {
      full += piece;
      onTok(piece, organs);
    }
  });
  return full;
}

export async function trainModel(model: string, epochs: number): Promise<{
  logs: TrainLog[];
  lastLoss: number;
  trainedEpochs: number;
  organs?: OrganPulse[];
}> {
  const res = await fetch("/api/metatron/train", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model, epochs }),
  });
  if (!res.ok) throw new Error(`train ${res.status}`);
  return (await res.json()) as {
    logs: TrainLog[];
    lastLoss: number;
    trainedEpochs: number;
    organs?: OrganPulse[];
  };
}

export function scaleIdFromTag(tag: string): ScaleId {
  if (tag.includes("nano")) return "nano";
  if (tag.includes("tiny")) return "tiny";
  return "ultra";
}
