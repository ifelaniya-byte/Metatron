import { ORGANS } from "./corpus";
import { getScale, type MetatronEngine, type OrganPulse, type Scale } from "./engine";
import { getEngine, listLibrary, listLoaded } from "./runtime";

export function nowIso() {
  return new Date().toISOString();
}

export function modelCard(scale: Scale, engine?: MetatronEngine, name?: string) {
  const tag = name ?? engine?.alias ?? scale.tag;
  return {
    name: tag,
    model: tag,
    modified_at: nowIso(),
    size: scale.params * 4,
    digest: `sha256:${scale.digest}${"0".repeat(48)}`.slice(0, 71),
    details: {
      parent_model: "",
      format: "gguf",
      family: "metatron",
      families: ["metatron", "flower-of-life"],
      parameter_size: scale.sizeLabel,
      quantization_level: "F32",
    },
  };
}

export function tagsPayload() {
  const extras = new Set<string>();
  const models = listLibrary().map((e) => {
    extras.add(e.scale.tag);
    return modelCard(e.scale, e, e.alias ?? e.scale.tag);
  });
  if (!extras.has("metatron:latest")) {
    const ultra = getEngine("ultra");
    models.push(modelCard(ultra.scale, ultra, "metatron:latest"));
  }
  return { models };
}

export function showPayload(name: string) {
  const scale = getScale(name);
  const eng = getEngine(name);
  return {
    ...modelCard(scale, eng, name.replace(/^ollama\//, "")),
    modelfile: modelfileFor(scale),
    parameters: `temperature 0.3\nnum_ctx ${scale.ctx}\ntop_k 40\nrepeat_penalty 1.1`,
    template: "{{ .System }}\n\nUser: {{ .Prompt }}\nMetatron: ",
    system: "You are Metatron, a Flower-of-Life geometric language model.",
    license: "Metatron geometric runtime. Not a GGUF transformer.",
  };
}

export function modelfileFor(scale: Scale) {
  return `FROM metatron:${scale.id}
PARAMETER temperature 0.3
PARAMETER num_ctx ${scale.ctx}
PARAMETER top_k 40
PARAMETER stop "User:"
PARAMETER stop "<|im_end|>"
SYSTEM """
You are Metatron, a Flower-of-Life geometric modular language model.
Organs: brain, memory, ears, mouth, hands, heart, legs.
Keep replies concise. Do not pretend to be a frontier transformer.
"""
`;
}

export function openclawSnippet(scale: Scale, origin: string) {
  return `{
  "agents": {
    "defaults": {
      "model": { "primary": "ollama/${scale.tag}" },
      "models": {
        "ollama/${scale.tag}": {}
      }
    }
  },
  "plugins": {
    "entries": {
      "ollama": { "enabled": true }
    }
  },
  "models": {
    "providers": {
      "ollama": {
        "baseUrl": "${origin}",
        "api": "ollama",
        "apiKey": "ollama-local",
        "models": [
          {
            "id": "${scale.tag}",
            "name": "${scale.tag}",
            "reasoning": false,
            "input": ["text"],
            "contextWindow": ${Math.max(8192, scale.ctx)},
            "maxTokens": 1024,
            "compat": {
              "supportsTools": false,
              "supportsUsageInStreaming": true
            }
          }
        ]
      }
    }
  }
}`;
}

export function psPayload() {
  return {
    models: listLoaded().map((e) => ({
      ...modelCard(e.scale, e, e.alias ?? e.scale.tag),
      expires_at: new Date(Date.now() + 3600_000).toISOString(),
      size_vram: e.scale.params * 4,
    })),
  };
}

export function corsHeaders(): HeadersInit {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,DELETE,HEAD,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, x-api-key",
  };
}

export function json(data: unknown, status = 200) {
  return Response.json(data, { status, headers: corsHeaders() });
}

export function streamNdjson(write: (emit: (obj: unknown) => void) => Promise<void>): Response {
  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const emit = (obj: unknown) => {
        controller.enqueue(encoder.encode(JSON.stringify(obj) + "\n"));
      };
      try {
        await write(emit);
      } catch (err) {
        emit({ error: err instanceof Error ? err.message : String(err) });
      }
      controller.close();
    },
  });
  return new Response(stream, {
    headers: {
      ...corsHeaders(),
      "Content-Type": "application/x-ndjson",
      "Cache-Control": "no-cache",
      "X-Accel-Buffering": "no",
    },
  });
}

export async function handleGenerate(body: {
  model?: string;
  prompt?: string;
  stream?: boolean;
  options?: { temperature?: number; top_k?: number; num_predict?: number };
}) {
  const { ensureLoaded } = await import("./runtime");
  const eng = ensureLoaded(body.model ?? "metatron:ultra");
  const tokens: string[] = [];
  const organs: OrganPulse[][] = [];
  const text = eng.generate({
    prompt: body.prompt ?? "",
    temperature: body.options?.temperature ?? 0.7,
    topK: body.options?.top_k ?? 24,
    maxNew: body.options?.num_predict ?? 96,
    onToken: (tok, pulse) => {
      tokens.push(tok);
      organs.push(pulse);
    },
  });
  return { eng, text, tokens, organs };
}

export async function handleChat(body: {
  model?: string;
  messages?: { role: string; content: string }[];
  stream?: boolean;
  options?: { temperature?: number; top_k?: number };
}) {
  const { ensureLoaded } = await import("./runtime");
  const eng = ensureLoaded(body.model ?? "metatron:ultra");
  const tokens: string[] = [];
  const text = eng.chat(body.messages ?? [], {
    temperature: body.options?.temperature ?? 0.7,
    topK: body.options?.top_k ?? 24,
    onToken: (tok) => tokens.push(tok),
  });
  return { eng, text, tokens, organs: eng.lastOrgans };
}

export function openaiModels() {
  return {
    object: "list",
    data: listLibrary().map((e) => ({
      id: e.alias ?? e.scale.tag,
      object: "model",
      created: Math.floor(Date.now() / 1000),
      owned_by: "metatron",
    })),
  };
}

export { ORGANS };
