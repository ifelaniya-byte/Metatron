import {
  cloneEngine,
  getScale,
  MetatronEngine,
  SCALES,
  type Scale,
  type ScaleId,
  type TrainLog,
} from "./engine";

type G = typeof globalThis & {
  __metatronEngines?: Map<string, MetatronEngine>;
  __metatronAliases?: Map<string, string>;
};

function bag(): Map<string, MetatronEngine> {
  const g = globalThis as G;
  if (!g.__metatronEngines) g.__metatronEngines = new Map();
  return g.__metatronEngines;
}

function aliases(): Map<string, string> {
  const g = globalThis as G;
  if (!g.__metatronAliases) {
    g.__metatronAliases = new Map([
      ["metatron", "ultra"],
      ["metatron:latest", "ultra"],
      ["latest", "ultra"],
    ]);
  }
  return g.__metatronAliases;
}

function seedLibrary() {
  const m = bag();
  if (m.size) return;
  for (const s of SCALES) {
    if (!m.has(s.id)) m.set(s.id, new MetatronEngine(s));
  }
}

export function resolveId(name: string): ScaleId {
  const raw = name.replace(/^ollama\//, "").trim();
  const mapped = aliases().get(raw) ?? aliases().get(raw.toLowerCase());
  if (mapped === "nano" || mapped === "ultra" || mapped === "tiny") return mapped;
  return getScale(raw).id;
}

export function getEngine(name = "metatron:ultra"): MetatronEngine {
  seedLibrary();
  const id = resolveId(name);
  const m = bag();
  let eng = m.get(id);
  if (!eng) {
    eng = new MetatronEngine(getScale(id));
    m.set(id, eng);
  }
  return eng;
}

export function listLibrary(): MetatronEngine[] {
  seedLibrary();
  return [...bag().values()];
}

export function listLoaded(): MetatronEngine[] {
  return listLibrary().filter((e) => e.loaded);
}

export function findByTag(name: string): MetatronEngine | undefined {
  seedLibrary();
  const id = resolveId(name);
  const tagged = [...bag().entries()].find(([k, e]) => k === name || e.alias === name || e.scale.tag === name);
  if (tagged) return tagged[1];
  return bag().get(id);
}

export function registerAlias(from: string, to: string) {
  aliases().set(from, resolveId(to));
}

export function copyModel(source: string, destination: string): MetatronEngine {
  const src = getEngine(source);
  const dest = destination.replace(/^ollama\//, "").trim();
  const clone = cloneEngine(src, dest);
  bag().set(dest, clone);
  aliases().set(dest, src.scale.id);
  return clone;
}

export function deleteModel(name: string): boolean {
  const key = name.replace(/^ollama\//, "").trim();
  const m = bag();
  if (m.has(key)) {
    m.delete(key);
    aliases().delete(key);
    return true;
  }
  const id = resolveId(name);
  if (SCALES.some((s) => s.id === id)) {
    const eng = m.get(id);
    if (eng) {
      eng.loaded = false;
      eng.trainedEpochs = 0;
    }
    return true;
  }
  return m.delete(id);
}

export function ensureLoaded(name: string): MetatronEngine {
  const eng = getEngine(name);
  if (!eng.loaded) {
    const warm = eng.scale.id === "nano" ? 2 : eng.scale.id === "ultra" ? 3 : 4;
    eng.trainEpochs(warm);
  }
  return eng;
}

export function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

export async function pullModel(
  name: string,
  onEvent: (ev: Record<string, unknown>) => void,
): Promise<MetatronEngine> {
  const eng = getEngine(name);
  const s = eng.scale;
  const total = s.params * 4;
  onEvent({ status: "pulling manifest" });
  await sleep(60);
  if (eng.loaded) {
    onEvent({
      status: "pulling " + s.digest,
      digest: `sha256:${s.digest}${"0".repeat(48)}`.slice(0, 71),
      total,
      completed: total,
    });
    await sleep(40);
    onEvent({ status: "verifying sha256 digest" });
    await sleep(40);
    onEvent({ status: "success" });
    return eng;
  }
  const digest = `sha256:${s.digest}${"0".repeat(48)}`.slice(0, 71);
  onEvent({
    status: `pulling ${digest}`,
    digest,
    total,
    completed: 0,
  });
  await sleep(50);
  onEvent({ status: `pulling flower-of-life topology (${s.modules} modules)` });
  await sleep(70);
  onEvent({ status: "pulling organ seeds: brain memory ears mouth hands heart legs" });
  await sleep(60);
  const warm = s.id === "nano" ? 2 : s.id === "ultra" ? 3 : 4;
  for (let i = 0; i < warm; i++) {
    const [log] = eng.trainEpochs(1);
    const completed = Math.round(((i + 1) / warm) * total);
    onEvent({
      status: `pulling ${digest}`,
      digest,
      total,
      completed,
    });
    if (log) {
      onEvent({
        status: `warming weights  epoch ${log.epoch}  loss ${log.loss.toFixed(3)}  ppl ${log.ppl.toFixed(1)}`,
      });
    }
    await sleep(16);
  }
  onEvent({ status: "verifying sha256 digest" });
  await sleep(50);
  onEvent({ status: "writing manifest" });
  await sleep(40);
  onEvent({ status: "success" });
  eng.loaded = true;
  return eng;
}

export function createFromModelfile(model: string, modelfile: string): { scale: Scale; tag: string } {
  const from = /FROM\s+(\S+)/i.exec(modelfile)?.[1] ?? "metatron:ultra";
  const tag = model.replace(/^ollama\//, "").trim() || `metatron:custom`;
  const src = ensureLoaded(from);
  const clone = cloneEngine(src, tag);
  bag().set(tag, clone);
  aliases().set(tag, src.scale.id);
  return { scale: src.scale, tag };
}

export function trainMore(name: string, epochs: number): TrainLog[] {
  const eng = getEngine(name);
  return eng.trainEpochs(Math.max(1, Math.min(32, epochs)));
}
