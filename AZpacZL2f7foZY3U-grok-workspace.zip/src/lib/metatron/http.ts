import { getScale } from "./engine";
import {
  corsHeaders,
  handleChat,
  handleGenerate,
  json,
  nowIso,
  openaiModels,
  psPayload,
  showPayload,
  streamNdjson,
  tagsPayload,
} from "./ollama";
import {
  copyModel,
  createFromModelfile,
  deleteModel,
  getEngine,
  pullModel,
  sleep,
  trainMore,
} from "./runtime";

export async function handleOllama(request: Request, splat: string): Promise<Response> {
  const path = splat.replace(/^\/+/, "").replace(/\/+$/, "");
  const method = request.method.toUpperCase();

  if (method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders() });
  }

  if ((path === "tags" || path === "api/tags") && method === "GET") return json(tagsPayload());
  if ((path === "version" || path === "api/version") && (method === "GET" || method === "HEAD")) {
    return json({ version: "0.12.metatron" });
  }
  if ((path === "ps" || path === "api/ps") && method === "GET") return json(psPayload());
  if ((path === "models" || path === "v1/models" || path === "api/v1/models") && method === "GET") {
    return json(openaiModels());
  }

  const body = method === "GET" || method === "HEAD" ? {} : await request.json().catch(() => ({}));

  if (path === "show" && method === "POST") {
    const name = String((body as { name?: string; model?: string }).name ?? (body as { model?: string }).model ?? "metatron:ultra");
    return json(showPayload(name));
  }

  if (path === "pull" && method === "POST") {
    const name = String((body as { name?: string; model?: string }).name ?? (body as { model?: string }).model ?? "metatron:ultra");
    const stream = (body as { stream?: boolean }).stream !== false;
    if (!stream) {
      await pullModel(name, () => undefined);
      const eng = getEngine(name);
      return json({ status: "success", digest: eng.scale.digest });
    }
    return streamNdjson(async (emit) => {
      await pullModel(name, emit);
    });
  }

  if (path === "create" && method === "POST") {
    const model = String((body as { model?: string; name?: string }).model ?? (body as { name?: string }).name ?? "metatron:custom");
    const modelfile = String((body as { modelfile?: string }).modelfile ?? "");
    const stream = (body as { stream?: boolean }).stream !== false;
    const run = async (emit: (o: unknown) => void) => {
      emit({ status: "parsing modelfile" });
      await sleep(40);
      const created = createFromModelfile(model, modelfile);
      emit({ status: `using FROM ${created.scale.tag}` });
      await pullModel(created.tag, emit);
    };
    if (!stream) {
      await run(() => undefined);
      return json({ status: "success" });
    }
    return streamNdjson(run);
  }

  if (path === "copy" && method === "POST") {
    const source = String((body as { source?: string }).source ?? "");
    const destination = String((body as { destination?: string }).destination ?? "");
    if (!source || !destination) return json({ error: "source and destination required" }, 400);
    copyModel(source, destination);
    return json({});
  }

  if (path === "delete" && (method === "DELETE" || method === "POST")) {
    const name = String((body as { name?: string; model?: string }).name ?? (body as { model?: string }).model ?? "");
    if (!name) return json({ error: "model required" }, 400);
    const ok = deleteModel(name);
    return json(ok ? {} : { error: "model not found" }, ok ? 200 : 404);
  }

  if ((path === "embed" || path === "embeddings") && method === "POST") {
    const b = body as { model?: string; input?: string | string[]; prompt?: string };
    const eng = getEngine(b.model ?? "metatron:ultra");
    const inputs = Array.isArray(b.input) ? b.input : [b.input ?? b.prompt ?? ""];
    const embeddings = inputs.map((t) => eng.embedText(String(t)));
    return json({ model: eng.scale.tag, embeddings });
  }

  if (path === "generate" && method === "POST") {
    return generateResponse(body as Record<string, unknown>);
  }

  if (path === "chat" && method === "POST") {
    return chatResponse(body as Record<string, unknown>);
  }

  if (
    (path === "v1/chat/completions" ||
      path === "chat/completions" ||
      path === "api/v1/chat/completions") &&
    method === "POST"
  ) {
    return openaiChat(body as Record<string, unknown>);
  }

  if ((path === "metatron/train" || path === "train") && method === "POST") {
    const b = body as { model?: string; epochs?: number };
    const logs = trainMore(b.model ?? "metatron:ultra", b.epochs ?? 4);
    const eng = getEngine(b.model ?? "metatron:ultra");
    return json({
      model: eng.scale.tag,
      logs,
      lastLoss: eng.lastLoss,
      trainedEpochs: eng.trainedEpochs,
      organs: eng.lastOrgans,
    });
  }

  return json({ error: `unknown ollama path /${path}` }, 404);
}

async function generateResponse(body: Record<string, unknown>) {
  const stream = body.stream !== false;
  const { eng, text, tokens } = await handleGenerate({
    model: body.model as string | undefined,
    prompt: body.prompt as string | undefined,
    options: body.options as { temperature?: number; top_k?: number; num_predict?: number },
  });
  const base = {
    model: eng.alias ?? eng.scale.tag,
    created_at: nowIso(),
    done_reason: "stop",
    context: [] as number[],
    total_duration: 12_000_000,
    load_duration: 1_000_000,
    prompt_eval_count: String(body.prompt ?? "").length,
    eval_count: text.length,
    organs: eng.lastOrgans,
  };
  if (!stream) {
    return json({ ...base, response: text, done: true });
  }
  return streamNdjson(async (emit) => {
    for (const tok of tokens) {
      emit({ ...base, response: tok, done: false });
      await sleep(12);
    }
    emit({ ...base, response: "", done: true });
  });
}

async function chatResponse(body: Record<string, unknown>) {
  const stream = body.stream !== false;
  const { eng, text, tokens } = await handleChat({
    model: body.model as string | undefined,
    messages: body.messages as { role: string; content: string }[] | undefined,
    options: body.options as { temperature?: number; top_k?: number },
  });
  const model = eng.alias ?? eng.scale.tag;
  if (!stream) {
    return json({
      model,
      created_at: nowIso(),
      message: { role: "assistant", content: text },
      done: true,
      done_reason: "stop",
      total_duration: 14_000_000,
      eval_count: text.length,
      organs: eng.lastOrgans,
    });
  }
  return streamNdjson(async (emit) => {
    for (const tok of tokens) {
      emit({
        model,
        created_at: nowIso(),
        message: { role: "assistant", content: tok },
        done: false,
        organs: eng.lastOrgans,
      });
      await sleep(12);
    }
    emit({
      model,
      created_at: nowIso(),
      message: { role: "assistant", content: "" },
      done: true,
      done_reason: "stop",
      organs: eng.lastOrgans,
    });
  });
}

async function openaiChat(body: Record<string, unknown>) {
  const stream = body.stream === true;
  const { eng, text, tokens } = await handleChat({
    model: body.model as string | undefined,
    messages: body.messages as { role: string; content: string }[] | undefined,
  });
  const model = eng.alias ?? eng.scale.tag;
  const id = `chatcmpl-metatron`;
  if (!stream) {
    return json({
      id,
      object: "chat.completion",
      created: Math.floor(Date.now() / 1000),
      model,
      choices: [{ index: 0, message: { role: "assistant", content: text }, finish_reason: "stop" }],
      usage: {
        prompt_tokens: 0,
        completion_tokens: tokens.length,
        total_tokens: tokens.length,
      },
    });
  }
  return streamNdjson(async (emit) => {
    for (const tok of tokens) {
      emit({
        id,
        object: "chat.completion.chunk",
        created: Math.floor(Date.now() / 1000),
        model,
        choices: [{ index: 0, delta: { content: tok }, finish_reason: null }],
      });
      await sleep(12);
    }
    emit({
      id,
      object: "chat.completion.chunk",
      created: Math.floor(Date.now() / 1000),
      model,
      choices: [{ index: 0, delta: {}, finish_reason: "stop" }],
    });
  });
}

export { getScale };
