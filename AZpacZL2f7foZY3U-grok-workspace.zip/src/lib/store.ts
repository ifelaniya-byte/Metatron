import { create } from "zustand";
import { SCALES, type OrganPulse, type Scale, type ScaleId, type TrainLog } from "@/lib/metatron/engine";
import { chatStream, fetchPs, fetchTags, pullModel, trainModel } from "@/lib/metatron/client";

export interface ChatMsg {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  organs?: OrganPulse[];
}

type Tab = "organs" | "train" | "connect";

interface AppState {
  scaleId: ScaleId;
  pulling: boolean;
  pullLog: string[];
  ready: boolean;
  messages: ChatMsg[];
  input: string;
  streaming: boolean;
  organs: OrganPulse[];
  tab: Tab;
  trainLogs: TrainLog[];
  training: boolean;
  loadedIds: ScaleId[];
  version: string;
  error: string | null;
  setInput: (v: string) => void;
  setTab: (t: Tab) => void;
  scale: () => Scale;
  boot: () => Promise<void>;
  loadScale: (id: ScaleId) => Promise<void>;
  send: (text?: string) => Promise<void>;
  train: (epochs: number) => Promise<void>;
}

let booted = false;

export const useApp = create<AppState>((set, get) => ({
  scaleId: "ultra",
  pulling: true,
  pullLog: [">>> ollama pull metatron:ultra"],
  ready: false,
  messages: [],
  input: "",
  streaming: false,
  organs: [],
  tab: "organs",
  trainLogs: [],
  training: false,
  loadedIds: [],
  version: "",
  error: null,
  setInput: (v) => set({ input: v }),
  setTab: (t) => set({ tab: t }),
  scale: () => SCALES.find((s) => s.id === get().scaleId) ?? SCALES[1]!,
  boot: async () => {
    if (booted) return;
    booted = true;
    await get().loadScale("ultra");
  },
  loadScale: async (id) => {
    set({
      scaleId: id,
      pulling: true,
      pullLog: [`>>> ollama pull metatron:${id}`],
      ready: false,
      error: null,
    });
    try {
      await pullModel(`metatron:${id}`, (line, raw) => {
        const done = String(raw.status ?? "") === "success";
        set((s) => ({
          pullLog: [...s.pullLog, line],
          pulling: done ? false : s.pulling,
          ready: done ? true : s.ready,
        }));
      });
      const ps = await fetchPs().catch(() => []);
      const loadedIds = uniqueIds(ps.map((m) => tagToId(m.name)));
      const scale = SCALES.find((s) => s.id === id) ?? SCALES[1]!;
      set((s) => ({
        pulling: false,
        ready: true,
        loadedIds: loadedIds.length ? loadedIds : s.loadedIds.includes(id) ? s.loadedIds : [...s.loadedIds, id],
        messages: [
          {
            id: "sys-loaded",
            role: "system",
            content: `metatron:${id} loaded · ${scale.sizeLabel} params · ${scale.modules} modules · ctx ${scale.ctx}`,
          },
        ],
      }));
    } catch (err) {
      set({
        pulling: false,
        ready: false,
        error: err instanceof Error ? err.message : "pull failed",
        pullLog: [...get().pullLog, `error: ${err instanceof Error ? err.message : "pull failed"}`],
      });
    }
  },
  send: async (text) => {
    const raw = (text ?? get().input).trim();
    if (!raw || get().streaming || get().pulling) return;
    const user: ChatMsg = { id: uid(), role: "user", content: raw };
    const asstId = uid();
    set((s) => ({
      input: "",
      streaming: true,
      messages: [...s.messages, user, { id: asstId, role: "assistant", content: "" }],
    }));
    const history = get()
      .messages.filter((m) => (m.role === "user" || m.role === "assistant") && m.id !== asstId && m.content)
      .map((m) => ({ role: m.role, content: m.content }));
    try {
      const reply = await chatStream(`metatron:${get().scaleId}`, history, (tok, organs) => {
        set((s) => ({
          organs: organs ?? s.organs,
          messages: s.messages.map((m) =>
            m.id === asstId ? { ...m, content: tok ? m.content + tok : m.content, organs } : m,
          ),
        }));
      });
      set((s) => ({
        streaming: false,
        messages: s.messages.map((m) => (m.id === asstId ? { ...m, content: m.content || reply } : m)),
      }));
    } catch (err) {
      set((s) => ({
        streaming: false,
        error: err instanceof Error ? err.message : "chat failed",
        messages: s.messages.map((m) =>
          m.id === asstId
            ? { ...m, content: m.content || "The runtime could not complete that turn." }
            : m,
        ),
      }));
    }
  },
  train: async (epochs) => {
    if (get().training || get().pulling || !get().ready) return;
    set({ training: true, tab: "train" });
    try {
      const result = await trainModel(`metatron:${get().scaleId}`, epochs);
      set((s) => ({
        training: false,
        trainLogs: [...s.trainLogs, ...result.logs],
        organs: result.organs ?? s.organs,
      }));
    } catch {
      set({ training: false });
    }
  },
}));

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

function tagToId(tag: string): ScaleId {
  if (tag.includes("nano")) return "nano";
  if (tag.includes("tiny")) return "tiny";
  return "ultra";
}

function uniqueIds(ids: ScaleId[]): ScaleId[] {
  return [...new Set(ids)];
}
