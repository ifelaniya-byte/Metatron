import { ORGANS, type OrganId } from "@/lib/metatron/corpus";
import type { OrganPulse } from "@/lib/metatron/engine";
import { cn } from "@/lib/utils";

const R = 18;
const CX = 140;
const CY = 132;

function hexRing(n: number, radius: number): { x: number; y: number }[] {
  if (n === 0) return [{ x: CX, y: CY }];
  const pts: { x: number; y: number }[] = [];
  for (let i = 0; i < 6; i++) {
    const a = (Math.PI / 3) * i - Math.PI / 6;
    const x0 = CX + radius * Math.cos(a);
    const y0 = CY + radius * Math.sin(a);
    if (n === 1) pts.push({ x: x0, y: y0 });
    else {
      const a2 = a + Math.PI / 3;
      for (let k = 0; k < n; k++) {
        pts.push({
          x: x0 + ((radius * k) / n) * Math.cos(a2),
          y: y0 + ((radius * k) / n) * Math.sin(a2),
        });
      }
    }
  }
  return pts;
}

const NODES = [...hexRing(0, 0), ...hexRing(1, R * 2), ...hexRing(2, R * 4)].slice(0, 19);

const ORGAN_AT: Record<OrganId, number> = {
  brain: 0,
  memory: 3,
  ears: 6,
  mouth: 9,
  hands: 12,
  heart: 15,
  legs: 1,
};

export function FlowerOfLife({
  pulses,
  modules: _modules = 13,
  className,
}: {
  pulses: OrganPulse[];
  modules?: number;
  className?: string;
}) {
  const act = new Map(pulses.map((p) => [p.id, p.activation]));
  const nodeAct = NODES.map((_, i) => {
    const organ = ORGANS.find((o) => ORGAN_AT[o.id] === i);
    if (organ) return act.get(organ.id) ?? 0.1;
    return 0.08 + ((i * 13) % 7) * 0.02;
  });

  return (
    <svg
      viewBox="0 0 280 264"
      className={cn("h-auto w-full", className)}
      aria-hidden="true"
    >
      <circle cx={CX} cy={CY} r={R * 5.4} fill="none" stroke="currentColor" strokeOpacity={0.06} />
      {NODES.map((p, i) => (
        <circle
          key={`c-${i}`}
          cx={p.x}
          cy={p.y}
          r={R}
          fill="none"
          stroke="currentColor"
          strokeOpacity={0.18 + nodeAct[i]! * 0.35}
          strokeWidth={1}
        />
      ))}
      {NODES.map((p, i) => {
        const organ = ORGANS.find((o) => ORGAN_AT[o.id] === i);
        const a = nodeAct[i]!;
        return (
          <g key={`n-${i}`}>
            <circle
              cx={p.x}
              cy={p.y}
              r={3.4 + a * 2.4}
              fill={organ ? "var(--color-accent)" : "var(--color-fg)"}
              fillOpacity={0.25 + a * 0.75}
            />
            {organ ? (
              <text
                x={p.x}
                y={p.y + 16}
                textAnchor="middle"
                className="fill-muted"
                fontSize="7"
                fontFamily="var(--font-sans)"
              >
                {organ.title}
              </text>
            ) : null}
          </g>
        );
      })}
    </svg>
  );
}
