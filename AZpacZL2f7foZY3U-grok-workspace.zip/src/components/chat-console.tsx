import { useEffect, useRef } from "react";
import { ArrowUp, Loader2 } from "lucide-react";
import { useApp } from "@/lib/store";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

const SUGGESTIONS = [
  "Who are you?",
  "How does the Flower of Life work?",
  "How do I load you in Ollama?",
  "the flower of life is",
];

export function ChatConsole() {
  const messages = useApp((s) => s.messages);
  const input = useApp((s) => s.input);
  const setInput = useApp((s) => s.setInput);
  const send = useApp((s) => s.send);
  const streaming = useApp((s) => s.streaming);
  const pulling = useApp((s) => s.pulling);
  const pullLog = useApp((s) => s.pullLog);
  const ready = useApp((s) => s.ready);
  const scaleId = useApp((s) => s.scaleId);
  const error = useApp((s) => s.error);
  const scroller = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scroller.current?.scrollTo({ top: scroller.current.scrollHeight, behavior: "smooth" });
  }, [messages, pullLog, streaming]);

  return (
    <section className="flex min-h-0 min-w-0 flex-1 flex-col bg-bg">
      <header className="flex h-12 shrink-0 items-center justify-between border-b border-border px-4">
        <p className="font-mono text-xs text-muted">
          <span className="text-subtle">$</span> ollama run <span className="text-fg">metatron:{scaleId}</span>
        </p>
        <span
          className={cn("size-1.5 rounded-full", ready && !pulling ? "bg-ok" : "bg-muted animate-pulse")}
          aria-label={ready ? "loaded" : "loading"}
        />
      </header>

      <div ref={scroller} className="min-h-0 flex-1 overflow-y-auto px-4 py-4">
        {pullLog.length > 0 ? (
          <pre className="mb-6 whitespace-pre-wrap font-mono text-xs leading-6 text-muted">
            {pullLog.join("\n")}
          </pre>
        ) : null}

        {error ? <p className="mb-4 font-mono text-xs text-danger">{error}</p> : null}

        {messages.map((m) => (
          <article key={m.id} className="mb-4">
            {m.role === "system" ? (
              <p className="font-mono text-xs text-subtle">{m.content}</p>
            ) : (
              <div className="flex gap-3">
                <span className="mt-0.5 w-16 shrink-0 font-mono text-3xs uppercase tracking-wider text-subtle">
                  {m.role === "user" ? "you" : "metatron"}
                </span>
                <p
                  className={cn(
                    "max-w-[62ch] text-sm leading-relaxed text-pretty",
                    m.role === "user" ? "text-muted" : "text-fg",
                  )}
                >
                  {m.content || (streaming ? "…" : "")}
                </p>
              </div>
            )}
          </article>
        ))}

        {ready && messages.filter((m) => m.role !== "system").length === 0 ? (
          <div className="mt-4 flex flex-wrap gap-2">
            {SUGGESTIONS.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => void send(s)}
                className="min-h-11 rounded-md border border-border bg-surface px-3 py-2 text-left text-xs text-muted transition-colors duration-[var(--motion-quick)] hover:border-line hover:text-fg"
              >
                {s}
              </button>
            ))}
          </div>
        ) : null}
      </div>

      <form
        className="shrink-0 border-t border-border p-3"
        onSubmit={(e) => {
          e.preventDefault();
          void send();
        }}
      >
        <div className="flex items-end gap-2 rounded-lg bg-surface p-1.5 shadow-[var(--shadow-border)]">
          <textarea
            rows={1}
            value={input}
            disabled={!ready || streaming}
            placeholder={pulling ? "Waiting for pull…" : "Send a message"}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                void send();
              }
            }}
            className="max-h-32 min-h-11 flex-1 resize-none bg-transparent px-3 py-2 font-sans text-sm text-fg outline-none placeholder:text-subtle"
          />
          <Button type="submit" size="icon" disabled={!ready || streaming || !input.trim()} aria-label="Send">
            {streaming ? <Loader2 className="animate-spin" /> : <ArrowUp />}
          </Button>
        </div>
      </form>
    </section>
  );
}
