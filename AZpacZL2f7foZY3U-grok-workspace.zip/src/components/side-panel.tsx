import { useEffect, useState } from "react";
import { Activity, Copy, Flower2, Radio, Terminal } from "lucide-react";
import { Line, LineChart, ResponsiveContainer, Tooltip as RTooltip, XAxis, YAxis } from "recharts";
import { ORGANS } from "@/lib/metatron/corpus";
import { getScale } from "@/lib/metatron/engine";
import { modelfileFor, openclawSnippet } from "@/lib/metatron/ollama";
import { fetchPs, fetchTags, fetchVersion } from "@/lib/metatron/client";
import { useApp } from "@/lib/store";
import { cn } from "@/lib/utils";
import { FlowerOfLife } from "@/components/flower-of-life";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const TABS = [
  { id: "organs" as const, label: "Organs", icon: Flower2 },
  { id: "train" as const, label: "Train", icon: Activity },
  { id: "connect" as const, label: "Connect", icon: Radio },
];

export function SidePanel() {
  const tab = useApp((s) => s.tab);
  const setTab = useApp((s) => s.setTab);
  return (
    <aside className="flex h-full min-h-0 w-full flex-col border-l border-border bg-surface">
      <nav className="flex shrink-0 border-b border-border">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={cn(
              "flex min-h-11 flex-1 items-center justify-center gap-1.5 py-3 text-xs font-medium uppercase tracking-wider transition-colors duration-[var(--motion-quick)]",
              tab === t.id ? "text-fg" : "text-subtle hover:text-muted",
            )}
          >
            <t.icon className="size-3.5" />
            {t.label}
          </button>
        ))}
      </nav>
      <div className="min-h-0 flex-1 overflow-y-auto p-4">
        {tab === "organs" ? <OrgansPane /> : null}
        {tab === "train" ? <TrainPane /> : null}
        {tab === "connect" ? <ConnectPane /> : null}
      </div>
    </aside>
  );
}

function OrgansPane() {
  const organs = useApp((s) => s.organs);
  const scaleId = useApp((s) => s.scaleId);
  const scale = getScale(scaleId);
  const act = new Map(organs.map((o) => [o.id, o.activation]));
  return (
    <div>
      <FlowerOfLife pulses={organs} modules={scale.modules} className="text-fg" />
      <ul className="mt-2 space-y-2">
        {ORGANS.map((o) => {
          const a = act.get(o.id) ?? 0;
          return (
            <li key={o.id} className="rounded-md bg-raised px-3 py-2">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-medium text-fg">{o.title}</span>
                <span className="font-mono text-3xs tabular-nums text-subtle">{Math.round(a * 100)}%</span>
              </div>
              <div className="mt-1.5 h-0.5 overflow-hidden rounded-full bg-line">
                <div
                  className="h-full bg-accent transition-[width] duration-[var(--motion-fast)] ease-[var(--ease-out)]"
                  style={{ width: `${Math.round(a * 100)}%` }}
                />
              </div>
              <p className="mt-1.5 text-xs leading-snug text-muted">{o.role}</p>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function TrainPane() {
  const logs = useApp((s) => s.trainLogs);
  const training = useApp((s) => s.training);
  const train = useApp((s) => s.train);
  const ready = useApp((s) => s.ready);
  const last = logs[logs.length - 1];
  return (
    <div>
      <div className="mb-3 flex items-end justify-between">
        <div>
          <p className="font-mono text-3xs uppercase tracking-widest text-subtle">Loss</p>
          <p className="font-mono text-lg tabular-nums text-fg">{last ? last.loss.toFixed(3) : "—"}</p>
        </div>
        <Badge variant={training ? "accent" : "outline"}>{training ? "running" : "idle"}</Badge>
      </div>
      <div className="h-36 rounded-md bg-raised p-2">
        {logs.length > 1 ? (
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={logs} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
              <XAxis dataKey="epoch" tick={{ fill: "var(--color-subtle)", fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "var(--color-subtle)", fontSize: 10 }} axisLine={false} tickLine={false} domain={["auto", "auto"]} />
              <RTooltip
                contentStyle={{
                  background: "var(--color-surface)",
                  border: "1px solid var(--color-border)",
                  fontSize: 11,
                  color: "var(--color-fg)",
                }}
              />
              <Line type="monotone" dataKey="loss" stroke="var(--color-accent)" strokeWidth={1.5} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <p className="flex h-full items-center justify-center text-xs text-subtle">Pull a model to seed the curve</p>
        )}
      </div>
      <div className="mt-3 grid grid-cols-3 gap-2">
        {[4, 8, 16].map((n) => (
          <Button key={n} variant="outline" size="sm" className="min-h-11" disabled={!ready || training} onClick={() => void train(n)}>
            {n} ep
          </Button>
        ))}
      </div>
      <p className="mt-3 text-xs leading-relaxed text-muted">
        More epochs jam the geometric core into the corpus. The skeleton stays the same size.
      </p>
    </div>
  );
}

function ConnectPane() {
  const scaleId = useApp((s) => s.scaleId);
  const ready = useApp((s) => s.ready);
  const scale = getScale(scaleId);
  const origin = typeof window !== "undefined" ? window.location.origin : "https://this-runtime";
  const file = modelfileFor(scale);
  const claw = openclawSnippet(scale, origin);
  const [probe, setProbe] = useState<string>("idle — click Probe");
  const [probing, setProbing] = useState(false);

  useEffect(() => {
    if (ready) void runProbe(setProbe);
  }, [ready]);

  return (
    <div className="space-y-4">
      <div>
        <div className="mb-1.5 flex items-center justify-between gap-2">
          <p className="text-xs font-medium text-fg">Live Ollama API</p>
          <Button
            variant="outline"
            size="sm"
            disabled={probing}
            onClick={() => void runProbe(setProbe, setProbing)}
          >
            Probe
          </Button>
        </div>
        <pre className="max-h-40 overflow-auto rounded-md bg-raised p-3 font-mono text-3xs leading-relaxed text-muted">
          {probe}
        </pre>
      </div>
      <div>
        <div className="mb-1.5 flex items-center gap-2 text-xs font-medium text-fg">
          <Terminal className="size-3.5 text-muted" />
          Modelfile
        </div>
        <CopyBlock text={file} />
      </div>
      <div>
        <p className="mb-1.5 text-xs font-medium text-fg">OpenClaw / Open WebUI</p>
        <p className="mb-2 text-xs leading-relaxed text-muted">
          This app is the Ollama host. Point the provider at this origin and set primary to ollama/{scale.tag}. Native
          routes live under /api; OpenAI-compatible under /v1.
        </p>
        <CopyBlock text={claw} />
      </div>
      <div>
        <p className="mb-1.5 text-xs font-medium text-fg">Ollama API</p>
        <ul className="space-y-1 font-mono text-xs text-muted">
          <li>GET /api/tags</li>
          <li>GET /api/ps</li>
          <li>POST /api/pull</li>
          <li>POST /api/show</li>
          <li>POST /api/generate</li>
          <li>POST /api/chat</li>
          <li>POST /api/create</li>
          <li>GET /v1/models</li>
          <li>POST /v1/chat/completions</li>
        </ul>
      </div>
    </div>
  );
}

async function runProbe(
  setProbe: (v: string) => void,
  setProbing?: (v: boolean) => void,
) {
  setProbing?.(true);
  try {
    const [version, tags, ps] = await Promise.all([fetchVersion(), fetchTags(), fetchPs()]);
    const lines = [
      `GET /api/version  ${version}`,
      `GET /api/tags     ${tags.length} models`,
      ...tags.map((t) => `  - ${t.name}  ${t.details?.parameter_size ?? ""}`),
      `GET /api/ps       ${ps.length} loaded`,
      ...ps.map((t) => `  - ${t.name}`),
    ];
    setProbe(lines.join("\n"));
  } catch (err) {
    setProbe(`probe failed: ${err instanceof Error ? err.message : "error"}`);
  } finally {
    setProbing?.(false);
  }
}

function CopyBlock({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="relative rounded-md bg-raised">
      <Button
        type="button"
        variant="ghost"
        size="icon-sm"
        className="absolute right-1 top-1"
        aria-label="Copy"
        onClick={async () => {
          try {
            await navigator.clipboard.writeText(text);
            setCopied(true);
            setTimeout(() => setCopied(false), 1400);
          } catch {
            setCopied(false);
          }
        }}
      >
        <Copy className="size-3.5" />
      </Button>
      <pre className="max-h-48 overflow-auto p-3 pr-9 font-mono text-3xs leading-relaxed text-muted">{text}</pre>
      {copied ? <span className="absolute bottom-2 right-2 font-mono text-3xs text-ok">copied</span> : null}
    </div>
  );
}
