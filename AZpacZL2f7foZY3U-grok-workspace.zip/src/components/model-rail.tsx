import { Check, Circle, Download } from "lucide-react";
import { SCALES } from "@/lib/metatron/engine";
import { useApp } from "@/lib/store";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export function ModelRail() {
  const scaleId = useApp((s) => s.scaleId);
  const ready = useApp((s) => s.ready);
  const pulling = useApp((s) => s.pulling);
  const loadedIds = useApp((s) => s.loadedIds);
  const loadScale = useApp((s) => s.loadScale);

  return (
    <aside className="flex h-full min-h-0 w-full flex-col border-r border-border bg-surface">
      <div className="flex items-center justify-between px-4 py-3">
        <div>
          <p className="font-mono text-3xs uppercase tracking-widest text-subtle">Library</p>
          <h2 className="mt-0.5 text-sm font-medium text-fg">Local models</h2>
        </div>
        <Badge variant="outline">{SCALES.length}</Badge>
      </div>
      <ul className="flex min-h-0 flex-1 flex-col gap-1 overflow-y-auto px-2 pb-3">
        {SCALES.map((m) => {
          const loaded = loadedIds.includes(m.id);
          const active = scaleId === m.id && ready;
          return (
            <li key={m.id}>
              <button
                type="button"
                disabled={pulling}
                onClick={() => void loadScale(m.id)}
                className={cn(
                  "flex min-h-11 w-full items-start gap-3 rounded-md px-3 py-2.5 text-left transition-colors duration-[var(--motion-quick)]",
                  active ? "bg-raised" : "hover:bg-raised/70",
                )}
              >
                <span className="mt-1 text-accent">
                  {active ? (
                    <Check className="size-3.5" />
                  ) : loaded ? (
                    <Circle className="size-3.5 fill-ok/80 text-ok" />
                  ) : (
                    <Download className="size-3.5 text-subtle" />
                  )}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="flex items-baseline justify-between gap-2">
                    <span className="truncate font-mono text-sm text-fg">{m.tag}</span>
                    <span className="font-mono text-3xs tabular-nums text-subtle">{m.sizeLabel}</span>
                  </span>
                  <span className="mt-0.5 block text-xs text-muted">
                    {m.modules} modules · dim {m.dim} · ctx {m.ctx}
                  </span>
                </span>
              </button>
            </li>
          );
        })}
      </ul>
      <div className="border-t border-border px-3 py-3">
        <p className="font-mono text-3xs leading-relaxed text-subtle">
          ollama pull metatron:ultra
          <br />
          ollama run metatron:ultra
        </p>
        <Button
          variant="accent"
          size="sm"
          className="mt-2 min-h-11 w-full"
          disabled={pulling}
          onClick={() => void loadScale(scaleId)}
        >
          {ready ? "Reload into Ollama" : "Load into Ollama"}
        </Button>
      </div>
    </aside>
  );
}
