import { createFileRoute } from "@tanstack/react-router";
import { corsHeaders } from "@/lib/metatron/ollama";
import { handleOllama } from "@/lib/metatron/http";

export const Route = createFileRoute("/api/$")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: corsHeaders() }),
      GET: async ({ params, request }) => handleOllama(request, params._splat ?? ""),
      POST: async ({ params, request }) => handleOllama(request, params._splat ?? ""),
      DELETE: async ({ params, request }) => handleOllama(request, params._splat ?? ""),
      HEAD: async ({ params, request }) => handleOllama(request, params._splat ?? ""),
    },
  },
});
