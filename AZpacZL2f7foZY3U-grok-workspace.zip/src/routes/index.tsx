import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Activity, Flower2, MessageSquare, Radio } from "lucide-react";
import { ChatConsole } from "@/components/chat-console";
import { ModelRail } from "@/components/model-rail";
import { SidePanel } from "@/components/side-panel";
import { useApp } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

type Pane = "models" | "chat" | "side";

function Home() {
  const boot = useApp((s) => s.boot);
  const ready = useApp((s) => s.ready);
  const pulling = useApp((s) => s.pulling);
  const scaleId = useApp((s) => s.scaleId);
  const tab = useApp((s) => s.tab);
  const setTab = useApp((s) => s.setTab);
  const [pane, setPane] = useState<Pane>("chat");

  useEffect(() => {
    void boot();
  }, [boot]);

  return (
    <main className="flex h-[100dvh] flex-col bg-bg text-fg">
      <header className="flex h-12 shrink-0 items-center justify-between border-b border-border px-4">
        <div className="flex items-center gap-3">
          <Mark />
          <div>
            <h1 className="text-sm font-semibold tracking-tight text-fg">Metatron</h1>
            <p className="font-mono text-3xs uppercase tracking-widest text-subtle">Ollama runtime</p>
          </div>
        </div>
        <p className="hidden font-mono text-xs text-muted sm:block">
          {ready ? (
            <>
              loaded <span className="text-fg">metatron:{scaleId}</span>
            </>
          ) : pulling ? (
            "pulling…"
          ) : (
            "idle"
          )}
        </p>
      </header>

      <div className="flex min-h-0 flex-1">
        <div
          className={cn(
            "h-full shrink-0",
            pane === "models" ? "flex w-full md:w-[260px]" : "hidden md:flex md:w-[260px]",
          )}
        >
          <ModelRail />
        </div>
        <div className={cn("min-h-0 min-w-0 flex-1 flex-col", pane === "chat" ? "flex" : "hidden md:flex")}>
          <ChatConsole />
        </div>
        <div
          className={cn(
            "h-full shrink-0",
            pane === "side" ? "flex w-full lg:w-[300px]" : "hidden lg:flex lg:w-[300px]",
          )}
        >
          <SidePanel />
        </div>
      </div>

      <nav className="flex shrink-0 border-t border-border lg:hidden">
        <MobileTab label="Models" icon={Flower2} active={pane === "models"} onClick={() => setPane("models")} />
        <MobileTab label="Run" icon={MessageSquare} active={pane === "chat"} onClick={() => setPane("chat")} />
        <MobileTab
          label="Train"
          icon={Activity}
          active={pane === "side" && tab === "train"}
          onClick={() => {
            setTab("train");
            setPane("side");
          }}
        />
        <MobileTab
          label="API"
          icon={Radio}
          active={pane === "side" && tab === "connect"}
          onClick={() => {
            setTab("connect");
            setPane("side");
          }}
        />
      </nav>
    </main>
  );
}

function MobileTab({
  label,
  icon: Icon,
  active,
  onClick,
}: {
  label: string;
  icon: typeof Flower2;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex h-12 flex-1 flex-col items-center justify-center gap-0.5 text-3xs uppercase tracking-wider",
        active ? "text-fg" : "text-subtle",
      )}
    >
      <Icon className="size-4" />
      {label}
    </button>
  );
}

function Mark() {
  return (
    <svg width="22" height="22" viewBox="0 0 22 22" aria-hidden="true" className="text-accent">
      <circle cx="11" cy="11" r="3.2" fill="none" stroke="currentColor" strokeWidth="1.2" />
      <circle cx="11" cy="7.2" r="3.2" fill="none" stroke="currentColor" strokeWidth="1.2" />
      <circle cx="14.3" cy="9.1" r="3.2" fill="none" stroke="currentColor" strokeWidth="1.2" />
      <circle cx="14.3" cy="12.9" r="3.2" fill="none" stroke="currentColor" strokeWidth="1.2" />
      <circle cx="11" cy="14.8" r="3.2" fill="none" stroke="currentColor" strokeWidth="1.2" />
      <circle cx="7.7" cy="12.9" r="3.2" fill="none" stroke="currentColor" strokeWidth="1.2" />
      <circle cx="7.7" cy="9.1" r="3.2" fill="none" stroke="currentColor" strokeWidth="1.2" />
    </svg>
  );
}
