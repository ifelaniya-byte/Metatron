#!/usr/bin/env python3
"""16px previews of candidate Metatron favicons."""
import math
from PIL import Image, ImageDraw

BG = (9, 9, 11, 255)
IVORY = (244, 241, 234, 255)
TEAL = (78, 168, 160, 255)


def hexagon(cx, cy, r):
    pts = []
    for i in range(6):
        a = math.radians(-90 + i * 60)
        pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts


def save(name, img):
    path = f"/workspace/.grok/{name}"
    img.save(path)
    print("wrote", path)


def mark_hex_circle(size):
    img = Image.new("RGBA", (size, size), BG)
    d = ImageDraw.Draw(img)
    s = size / 32
    sw = max(1, round(2.25 * s))
    d.rounded_rectangle([0, 0, size - 1, size - 1], radius=max(1, round(6 * s)), fill=BG)
    d.polygon(hexagon(16 * s, 16 * s, 12.2 * s), outline=IVORY, width=sw)
    pad = 6.2 * s
    d.ellipse([16 * s - pad, 16 * s - pad, 16 * s + pad, 16 * s + pad], outline=TEAL, width=sw)
    return img


def mark_vesica(size):
    img = Image.new("RGBA", (size, size), BG)
    d = ImageDraw.Draw(img)
    s = size / 32
    sw = max(1, round(2.25 * s))
    r = 8.6 * s
    for cx, col in ((12.4 * s, IVORY), (19.6 * s, TEAL)):
        d.ellipse([cx - r, 16 * s - r, cx + r, 16 * s + r], outline=col, width=sw)
    return img


def mark_circle_hex(size):
    img = Image.new("RGBA", (size, size), BG)
    d = ImageDraw.Draw(img)
    s = size / 32
    sw = max(1, round(2.2 * s))
    r = 10.4 * s
    d.ellipse([16 * s - r, 16 * s - r, 16 * s + r, 16 * s + r], outline=IVORY, width=sw)
    d.polygon(hexagon(16 * s, 16 * s, 6.6 * s), outline=TEAL, width=sw)
    return img


if __name__ == "__main__":
    for fn, maker in (
        ("fav-hex-circle", mark_hex_circle),
        ("fav-vesica", mark_vesica),
        ("fav-circle-hex", mark_circle_hex),
    ):
        for sz in (16, 32, 64):
            save(f"{fn}-{sz}.png", maker(sz))
