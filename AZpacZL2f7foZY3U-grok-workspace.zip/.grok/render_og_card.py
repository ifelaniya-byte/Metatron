#!/usr/bin/env python3
"""Render Metatron OG card: Flower of Life + title lockup at 1200x630."""
from __future__ import annotations

import math
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

W, H = 1200, 630
SCALE = 4
SW, SH = W * SCALE, H * SCALE

BG = np.array([9, 9, 11], dtype=np.float64)  # #09090b
IVORY = np.array([244, 241, 234], dtype=np.float64)  # #f4f1ea
TEAL = np.array([78, 168, 160], dtype=np.float64)  # #4ea8a0
BORDER = np.array([38, 38, 43], dtype=np.float64)  # #26262b

FONT_SERIF = "/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf"
FONT_SERIF_I = "/usr/share/fonts/truetype/liberation/LiberationSerif-Italic.ttf"
OUT = Path("/workspace/.grok/og-raw.png")


def over(dst: np.ndarray, src_rgb: np.ndarray, alpha: np.ndarray) -> None:
    a = np.clip(alpha, 0.0, 1.0)[..., None]
    dst *= 1.0 - a
    dst += src_rgb * a


def stroke_circle(canvas, cx, cy, r, stroke, rgb, alpha=1.0) -> None:
    pad = int(stroke + 3)
    x0 = max(0, int(math.floor(cx - r - pad)))
    x1 = min(canvas.shape[1], int(math.ceil(cx + r + pad)) + 1)
    y0 = max(0, int(math.floor(cy - r - pad)))
    y1 = min(canvas.shape[0], int(math.ceil(cy + r + pad)) + 1)
    if x1 <= x0 or y1 <= y0:
        return
    yy, xx = np.ogrid[y0:y1, x0:x1]
    dist = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2)
    half = stroke * 0.5
    cov = np.clip(half + 0.65 - np.abs(dist - r), 0.0, 1.0) * alpha
    over(canvas[y0:y1, x0:x1], rgb, cov)


def stroke_rect(canvas, x0, y0, x1, y1, stroke, rgb, alpha=1.0) -> None:
    pad = int(stroke + 2)
    gx0 = max(0, int(math.floor(x0 - pad)))
    gx1 = min(canvas.shape[1], int(math.ceil(x1 + pad)) + 1)
    gy0 = max(0, int(math.floor(y0 - pad)))
    gy1 = min(canvas.shape[0], int(math.ceil(y1 + pad)) + 1)
    yy, xx = np.ogrid[gy0:gy1, gx0:gx1]
    dx = np.maximum(x0 - xx, xx - x1)
    dy = np.maximum(y0 - yy, yy - y1)
    dist_out = np.sqrt(np.maximum(dx, 0) ** 2 + np.maximum(dy, 0) ** 2)
    dist_in = np.maximum(dx, dy)
    signed = np.where((dx > 0) | (dy > 0), dist_out, dist_in)
    half = stroke * 0.5
    cov = np.clip(half + 0.65 - np.abs(signed), 0.0, 1.0) * alpha
    over(canvas[gy0:gy1, gx0:gx1], rgb, cov)


def fol_centers(rings: int, spacing: float):
    pts = []
    for q in range(-rings, rings + 1):
        for r in range(-rings, rings + 1):
            s = -q - r
            d = max(abs(q), abs(r), abs(s))
            if d <= rings:
                x = spacing * (q + r / 2.0)
                y = spacing * (r * math.sqrt(3) / 2.0)
                pts.append((x, y, d))
    return pts


def tracked_width(text: str, font, extra: int) -> int:
    widths = [font.getbbox(ch)[2] - font.getbbox(ch)[0] for ch in text]
    return sum(widths) + extra * (len(text) - 1)


def draw_tracked(draw: ImageDraw.ImageDraw, text: str, y: float, font, fill, extra: int, cx: int, anchor_top=True) -> None:
    glyphs = list(text)
    widths = [font.getbbox(ch)[2] - font.getbbox(ch)[0] for ch in glyphs]
    total = sum(widths) + extra * (len(glyphs) - 1)
    x = cx - total / 2
    for ch, cw in zip(glyphs, widths):
        draw.text((x, y), ch, font=font, fill=fill, anchor="lt")
        x += cw + extra


def main() -> None:
    canvas = np.broadcast_to(BG, (SH, SW, 3)).copy()

    inset = 36 * SCALE
    stroke_rect(canvas, inset, inset, SW - inset, SH - inset, 1.15 * SCALE, BORDER, 1.0)

    # Cover lockup: FoL above, title spanning ~half the frame, subtitle under.
    R = 44.0 * SCALE
    rings = 2
    fol_bound = 3 * R
    title_px = 152 * SCALE
    sub_px = 23 * SCALE
    title_track = int(3.0 * SCALE)
    sub_track = int(5.0 * SCALE)
    gap_fol_title = 26 * SCALE
    gap_title_sub = 16 * SCALE

    font_title = ImageFont.truetype(FONT_SERIF, title_px)
    font_sub = ImageFont.truetype(FONT_SERIF_I, sub_px)
    title = "Metatron"
    sub = "Ollama runtime"
    tw = tracked_width(title, font_title, title_track)
    print(f"title width {tw / SCALE:.0f}px ({tw / SW:.0%} of frame)")

    tb = font_title.getbbox(title)
    title_h = tb[3] - tb[1]
    sb = font_sub.getbbox(sub)
    sub_h = sb[3] - sb[1]

    lockup_h = 2 * fol_bound + gap_fol_title + title_h + gap_title_sub + sub_h
    lockup_top = (SH - lockup_h) / 2

    cx = SW / 2
    fol_cy = lockup_top + fol_bound

    for x, y, d in fol_centers(rings, R):
        if d == 0:
            rgb, a, st = TEAL, 1.0, 1.75 * SCALE
        elif d == 1:
            rgb, a, st = IVORY, 0.94, 1.20 * SCALE
        else:
            rgb, a, st = IVORY, 0.70, 1.08 * SCALE
        stroke_circle(canvas, cx + x, fol_cy + y, R, st, rgb, a)

    rgb = np.clip(canvas, 0, 255).astype(np.uint8)
    img = Image.fromarray(rgb, "RGB").convert("RGBA")
    text_layer = Image.new("RGBA", (SW, SH), (0, 0, 0, 0))
    tdraw = ImageDraw.Draw(text_layer)
    ivory = (244, 241, 234, 255)

    title_y = lockup_top + 2 * fol_bound + gap_fol_title
    draw_tracked(tdraw, title, title_y, font_title, ivory, title_track, int(cx))
    sub_y = title_y + title_h + gap_title_sub
    draw_tracked(tdraw, sub, sub_y, font_sub, ivory, sub_track, int(cx))

    out = Image.alpha_composite(img, text_layer).convert("RGB")
    out = out.resize((W, H), Image.Resampling.LANCZOS)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    out.save(OUT, "PNG")
    print(f"wrote {OUT} {out.size} lockup_h={lockup_h / SCALE:.0f}")


if __name__ == "__main__":
    main()
